import Foundation
import CoreLocation


// swiftlint:disable:next orphaned_doc_comment
/// Experience — the core unit of Solo Compass.
///
/// NOT a place. NOT a POI. A concrete, time-bound, story-rich thing worth
/// doing, anchored to a place but not reducible to it.
///
/// Mirrors `packages/core/src/experience.ts`. Keep field names in sync.

// MARK: - Category

/// The kind of activity an experience represents, used to group and filter the map.
public enum ExperienceCategory: String, Codable, CaseIterable, Identifiable, Hashable {
    case culture, nature, food, coffee, work, wellness, nightlife, hidden

    public var id: String { rawValue }

    /// SF Symbol used on the filter bar.
    public var symbol: String {
        switch self {
        case .culture:   return "building.columns"
        case .nature:    return "leaf"
        case .food:      return "fork.knife"
        case .coffee:    return "cup.and.saucer"
        case .work:      return "laptopcomputer"
        case .wellness:  return "heart.circle"
        case .nightlife: return "moon.stars"
        case .hidden:    return "sparkles"
        }
    }

    /// Brand color per category — uses UIKit semantic colors that adapt to dark/light mode.


    public var localizedTitle: String {
        NSLocalizedString("category.\(rawValue)", comment: "Experience category")
    }
}

// MARK: - Time window

/// A recurring slot when an experience is at its best, scoped by hour, weekday, and season.
public struct TimeWindow: Codable, Hashable {
    public let startHour: Int       // 0–23
    public let endHour: Int         // 0–23
    public let dayOfWeek: [Int]?    // 0=Sun..6=Sat
    public let season: [Int]?       // months 1-12
    public let note: String?

    public init(startHour: Int, endHour: Int, dayOfWeek: [Int]? = nil, season: [Int]? = nil, note: String? = nil) {
        self.startHour = startHour
        self.endHour = endHour
        self.dayOfWeek = dayOfWeek
        self.season = season
        self.note = note
    }

    /// Is the window open at the given hour (local)?
    public func contains(hour: Int) -> Bool {
        if startHour <= endHour { return hour >= startHour && hour < endHour }
        // wraps midnight
        return hour >= startHour || hour < endHour
    }
}

// MARK: - Location

/// Where an experience happens: its coordinates plus enriched place details like
/// rating, hours, and contact info pulled from map providers.
public struct ExperienceLocation: Codable, Hashable {
    /// GeoJSON convention: [longitude, latitude].
    public let coordinates: [Double]
    public let cityCode: String
    public let addressHint: String?
    public let placeNameLocal: String?
    public let placeNameRomanized: String?
    // Cross-channel hard signals enriched from Foursquare / Apple MapKit.
    // All optional; OSM-only places leave them nil. Mirrors the TS schema.
    public let rating: Double?         // 0–10 normalized provider rating
    public let openingHours: String?   // raw provider hours string
    public let priceLevel: Double?     // 1–4 (1 = cheap, 4 = expensive)
    public let website: String?
    public let phone: String?
    /// Photos attached to the place. User-created experiences populate this from
    /// the photo picker; seed/OSM places leave it nil. Values are URL strings:
    /// local `file://` paths until synced, then remote https URLs. Mirrors TS.
    public let photoUrls: [String]?

    public var clCoordinate: CLLocationCoordinate2D? {
        guard coordinates.count >= 2 else { return nil }
        return CLLocationCoordinate2D(latitude: coordinates[1], longitude: coordinates[0])
    }

    /// Returns a copy with `photoUrls` replaced. Used when photos resolve after
    /// the location was first built (e.g. async Wikidata enrichment).
    public func withPhotoUrls(_ urls: [String]?) -> ExperienceLocation {
        ExperienceLocation(
            coordinates: coordinates, cityCode: cityCode, addressHint: addressHint,
            placeNameLocal: placeNameLocal, placeNameRomanized: placeNameRomanized,
            rating: rating, openingHours: openingHours, priceLevel: priceLevel,
            website: website, phone: phone, photoUrls: urls
        )
    }

    public init(
        coordinates: [Double],
        cityCode: String,
        addressHint: String? = nil,
        placeNameLocal: String? = nil,
        placeNameRomanized: String? = nil,
        rating: Double? = nil,
        openingHours: String? = nil,
        priceLevel: Double? = nil,
        website: String? = nil,
        phone: String? = nil,
        photoUrls: [String]? = nil
    ) {
        self.coordinates = coordinates
        self.cityCode = cityCode
        self.addressHint = addressHint
        self.placeNameLocal = placeNameLocal
        self.placeNameRomanized = placeNameRomanized
        self.rating = rating
        self.openingHours = openingHours
        self.priceLevel = priceLevel
        self.website = website
        self.phone = phone
        self.photoUrls = photoUrls
    }
}

// MARK: - HowTo step

/// A single ordered instruction in the step-by-step guide for doing an experience.
public struct HowToStep: Codable, Hashable, Identifiable {
    public let order: Int
    public let text: String
    public var id: Int { order }

    public init(order: Int, text: String) {
        self.order = order
        self.text = text
    }
}

// MARK: - Real inconvenience

/// An honest heads-up about a downside of an experience — scams, crowds, weather, etc.
public struct RealInconvenience: Codable, Hashable, Identifiable {
    /// How seriously a warning should be presented to the traveler.
    public enum Severity {
        case high, medium, low

        public var backgroundOpacity: Double {
            switch self {
            case .high:   return 0.10
            case .medium: return 0.08
            case .low:    return 0.06
            }
        }
    }

    /// The kind of inconvenience a traveler might encounter at an experience.
    public enum Category: String, Codable, Hashable {
        case scam, crowds, logistics, weather, etiquette, safety, other

        public var symbol: String {
            switch self {
            case .scam:      return "exclamationmark.shield"
            case .crowds:    return "person.3.fill"
            case .logistics: return "map"
            case .weather:   return "cloud.rain"
            case .etiquette: return "hand.raised"
            case .safety:    return "shield.lefthalf.filled"
            case .other:     return "info.circle"
            }
        }

        public var severity: Severity {
            switch self {
            case .scam, .safety:                       return .high
            case .crowds, .weather, .logistics, .etiquette: return .medium
            case .other:                               return .low
            }
        }

        public var label: String {
            switch self {
            case .safety:    return NSLocalizedString("inconvenience.category.safety", comment: "Inconvenience category: safety")
            case .scam:      return NSLocalizedString("inconvenience.category.scam", comment: "Inconvenience category: scam")
            case .crowds:    return NSLocalizedString("inconvenience.category.crowds", comment: "Inconvenience category: crowds")
            case .logistics: return NSLocalizedString("inconvenience.category.logistics", comment: "Inconvenience category: logistics")
            case .weather:   return NSLocalizedString("inconvenience.category.weather", comment: "Inconvenience category: weather")
            case .etiquette: return NSLocalizedString("inconvenience.category.etiquette", comment: "Inconvenience category: etiquette")
            case .other:     return NSLocalizedString("inconvenience.category.other", comment: "Inconvenience category: note/other")
            }
        }
    }

    public let category: Category
    public let text: String
    public var id: String { "\(category.rawValue)-\(text.hashValue)" }

    public init(category: Category, text: String) {
        self.category = category
        self.text = text
    }
}

// MARK: - Solo Score

/// How comfortable an experience is for someone visiting alone, as an overall
/// rating plus the factors that produced it.
public struct SoloScore: Codable, Hashable {
    /// The individual solo-friendliness factors that combine into the overall score.
    public struct Breakdown: Codable, Hashable {
        public let seatingFriendly: Double
        public let soloPatronRatio: Double
        public let staffPressure: Double
        public let soloPortioning: Double
        public let ambianceFit: Double
        public let safety: Double

        public init(
            seatingFriendly: Double,
            soloPatronRatio: Double,
            staffPressure: Double,
            soloPortioning: Double,
            ambianceFit: Double,
            safety: Double
        ) {
            self.seatingFriendly = seatingFriendly
            self.soloPatronRatio = soloPatronRatio
            self.staffPressure = staffPressure
            self.soloPortioning = soloPortioning
            self.ambianceFit = ambianceFit
            self.safety = safety
        }
    }

    public let overall: Double      // 0-10
    public let breakdown: Breakdown
    public let hint: String?
    public let basedOnCount: Int

    public init(overall: Double, breakdown: Breakdown, hint: String? = nil, basedOnCount: Int) {
        self.overall = overall
        self.breakdown = breakdown
        self.hint = hint
        self.basedOnCount = basedOnCount
    }

    /// Visual color for the overall score: red→yellow→green.

}

// MARK: - Category highlight

/// A category-specific, scannable fact surfaced on the card — the detail that
/// matters most for *this kind* of place. A café highlight might be
/// "Wi-Fi · fast", a meal "Signature · pho bo", a temple "Best light · sunrise".
///
/// Kept deliberately generic (icon + label + value) so the LLM can emit a
/// different *set* of highlights per category without the schema growing a
/// dozen optional columns, and the UI renders them all with one pill view.
/// Only facts derivable from real signals/tags should be filled — never invented.
public struct CategoryHighlight: Codable, Hashable, Identifiable {
    /// A small, fixed vocabulary of highlight kinds. The raw value doubles as a
    /// stable id and selects the SF Symbol + accent, so the LLM picks from this
    /// set rather than free-forming icons.
    public enum Kind: String, Codable, Hashable, CaseIterable {
        // food
        case signature        // a dish/specialty the place is known for
        case pricePerPerson   // typical spend for one
        case waitTime         // expect a queue / walk right in
        // coffee / work
        case wifi             // wifi availability / quality
        case power            // power outlets at seats
        case longStay         // comfortable to linger 2h+
        // culture / nature
        case bestLight        // golden hour / best time to see
        case ticket           // entry fee / free
        case duration         // how long to budget
        // wellness / nightlife / generic
        case booking          // reservation needed / walk-in
        case vibe             // ambiance one-word
        case note             // anything else worth a glance

        /// SF Symbol shown on the highlight pill.
        public var symbol: String {
            switch self {
            case .signature:      return "star.circle"
            case .pricePerPerson: return "yensign.circle"
            case .waitTime:       return "hourglass"
            case .wifi:           return "wifi"
            case .power:          return "powerplug"
            case .longStay:       return "clock.arrow.circlepath"
            case .bestLight:      return "sun.max"
            case .ticket:         return "ticket"
            case .duration:       return "timer"
            case .booking:        return "calendar"
            case .vibe:           return "sparkles"
            case .note:           return "info.circle"
            }
        }
    }

    public let kind: Kind
    /// Short noun for the fact, e.g. "Wi-Fi", "Signature". Localized upstream
    /// (model emits it in the requested output language).
    public let label: String
    /// The actual value, e.g. "fast", "pho bo", "free". Kept under ~4 words.
    public let value: String

    public var id: String { "\(kind.rawValue)-\(value)" }

    public init(kind: Kind, label: String, value: String) {
        self.kind = kind
        self.label = label
        self.value = value
    }
}

// MARK: - Health & Confidence

/// How likely an experience is still real and accurate, shown to travelers as a
/// freshness indicator from healthy to possibly gone.
public enum HealthStatus: String, Codable {
    case healthy
    case fading
    case questioned
    case mayBeGone

    public var symbol: String {
        switch self {
        case .healthy:    return "checkmark.circle.fill"
        case .fading:     return "clock.badge.questionmark"
        case .questioned: return "exclamationmark.circle.fill"
        case .mayBeGone:  return "xmark.circle.fill"
        }
    }



    public var localizedDescription: String {
        NSLocalizedString("health.\(rawValue)", comment: "Health status label")
    }

    /// SF Symbol to overlay on the compact dot so colorblind users can distinguish states by shape.
    public var accessibilitySymbol: String? {
        switch self {
        case .healthy:    return nil
        case .fading:     return "clock"
        case .questioned: return "questionmark"
        case .mayBeGone:  return "xmark"
        }
    }
}

/// How much we trust that an experience's information is current, derived from
/// when it was last verified and the signals backing it up.
public struct Confidence: Codable, Hashable {
    /// The raw evidence behind a confidence level: scrape age, GPS visits, and reports.
    public struct Signals: Codable, Hashable {
        public let aiScrapeAgeDays: Int
        public let passiveGpsHits30d: Int
        public let activeReports30d: Int
        public let trustedVerifications: Int

        public init(aiScrapeAgeDays: Int, passiveGpsHits30d: Int, activeReports30d: Int, trustedVerifications: Int) {
            self.aiScrapeAgeDays = aiScrapeAgeDays
            self.passiveGpsHits30d = passiveGpsHits30d
            self.activeReports30d = activeReports30d
            self.trustedVerifications = trustedVerifications
        }

        public var totalCount: Int {
            passiveGpsHits30d + activeReports30d + trustedVerifications
        }
    }

    public let level: Int           // 0–5
    public let lastVerifiedAt: Date
    public let reason: String
    public let signals: Signals

    public init(level: Int, lastVerifiedAt: Date, reason: String, signals: Signals) {
        self.level = max(0, min(5, level))
        self.lastVerifiedAt = lastVerifiedAt
        self.reason = reason
        self.signals = signals
    }

    /// Mirror of `healthFromConfidence` in TS.
    public var health: HealthStatus {
        let ageDays = Date().timeIntervalSince(lastVerifiedAt) / 86_400
        if ageDays > 60 { return .mayBeGone }
        if level >= 3 && ageDays < 30 { return .healthy }
        if level >= 2 && ageDays < 30 { return .fading }
        return .questioned
    }
}

// MARK: - Information Source

/// An attributed origin for an experience's information — where the details came
/// from and when that source was last verified.
public struct InformationSource: Codable, Hashable, Identifiable {
    /// The kind of place an experience's information was sourced from.
    public enum SourceType: String, Codable, Hashable {
        // `amap` marks AutoNavi/高德 as provenance for mainland-China POIs.
        // Per ADR-amap-china-poi §3.2 only this attribution flag persists,
        // never the raw structured fields (address/phone/rating/hours).
        case wikivoyage, wikipedia, reddit, blog, youtube, user, fieldVisit = "field_visit", amap
    }

    public let type: SourceType
    public let url: URL?
    public let attribution: String?
    public let verifiedAt: Date

    public var id: String {
        "\(type.rawValue)-\(url?.absoluteString ?? attribution ?? UUID().uuidString)"
    }

    public init(type: SourceType, url: URL? = nil, attribution: String? = nil, verifiedAt: Date) {
        self.type = type
        self.url = url
        self.attribution = attribution
        self.verifiedAt = verifiedAt
    }
}

// MARK: - Experience

/// The core unit of Solo Compass: a concrete, time-bound, story-rich thing worth
/// doing alone, bundling its location, timing, guidance, score, and provenance.
public struct Experience: Codable, Hashable, Identifiable {
    /// The typical shortest-to-longest time, in minutes, an experience takes.
    public struct DurationRange: Codable, Hashable {
        public let min: Int
        public let max: Int
        public init(min: Int, max: Int) { self.min = min; self.max = max }
    }

    /// Aggregate usage data for an experience: how often it's been done and how it rated.
    public struct Stats: Codable, Hashable {
        public let completionCount: Int
        public let averageRating: Double // 0-5
        public let lastCompletedAt: Date?
        public init(completionCount: Int, averageRating: Double, lastCompletedAt: Date? = nil) {
            self.completionCount = completionCount
            self.averageRating = averageRating
            self.lastCompletedAt = lastCompletedAt
        }
    }

    /// Where an experience sits in its lifecycle, from unverified candidate to retired.
    public enum Status: String, Codable, Hashable {
        case candidate, active, stale, retired
    }

    public let id: String
    public let title: String
    public let oneLiner: String
    public let whyItMatters: String
    public let category: ExperienceCategory
    public let location: ExperienceLocation
    public let bestTimes: [TimeWindow]
    public let durationMinutes: DurationRange
    public let howTo: [HowToStep]
    /// Category-specific scannable facts (Wi-Fi for cafés, signature dish for
    /// food, best light for sights). Optional + decoded leniently so older
    /// persisted/seed entries without it stay valid; treated as `[]` in the UI.
    public let categoryHighlights: [CategoryHighlight]?
    public let realInconveniences: [RealInconvenience]
    public let soloScore: SoloScore
    public let sources: [InformationSource]
    public let confidence: Confidence
    public let nearbyExperienceIds: [String]
    public let stats: Stats
    public let status: Status
    public let createdAt: Date
    public let updatedAt: Date

    /// User-defined free-form tags layered on top of the category enum.
    /// Optional in JSON; treated as `[]` everywhere a non-nil array is expected.
    public let userTags: [String]?

    public init(
        id: String,
        title: String,
        oneLiner: String,
        whyItMatters: String,
        category: ExperienceCategory,
        location: ExperienceLocation,
        bestTimes: [TimeWindow],
        durationMinutes: DurationRange,
        howTo: [HowToStep],
        realInconveniences: [RealInconvenience],
        soloScore: SoloScore,
        sources: [InformationSource],
        confidence: Confidence,
        nearbyExperienceIds: [String],
        stats: Stats,
        status: Status,
        createdAt: Date,
        updatedAt: Date,
        userTags: [String]? = nil,
        categoryHighlights: [CategoryHighlight]? = nil
    ) {
        self.id = id
        self.title = title
        self.oneLiner = oneLiner
        self.whyItMatters = whyItMatters
        self.category = category
        self.location = location
        self.bestTimes = bestTimes
        self.durationMinutes = durationMinutes
        self.howTo = howTo
        self.realInconveniences = realInconveniences
        self.soloScore = soloScore
        self.sources = sources
        self.confidence = confidence
        self.nearbyExperienceIds = nearbyExperienceIds
        self.stats = stats
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.userTags = userTags
        self.categoryHighlights = categoryHighlights
    }

    public var coordinate: CLLocationCoordinate2D? { location.clCoordinate }

    /// Numeric zero is retained for schema compatibility only; it is not an
    /// assessment of an unexplored place's quality or safety.
    public var soloScoreDisplay: String {
        guard soloScore.overall > 0 else {
            return NSLocalizedString("soloScore.unassessed", comment: "No solo assessment available")
        }
        return String(format: "%.1f", soloScore.overall)
    }

    /// Non-nil category highlights, never nil — UI iterates this directly.
    public var highlights: [CategoryHighlight] { categoryHighlights ?? [] }

    /// Compact display name: romanized place name → local name → full title.
    public var shortName: String {
        let candidates = [location.placeNameRomanized, location.placeNameLocal]
        if let name = candidates.compactMap({ $0 }).first(where: { !$0.isEmpty }) {
            return name
        }
        return title
    }

    /// True when this entry was discovered via OpenStreetMap Explore
    /// (vs. a curated seed entry). Used to surface provenance in the UI.
    public var isFromOpenStreetMap: Bool { id.hasPrefix("exp_osm_") }

    /// ID prefix for experiences a user creates by hand. Mirrors
    /// `EXP_USER_ID_PREFIX` in packages/core/src/experience.ts.
    public static let userIdPrefix = "exp_user_"

    /// True when the user registered this place themselves. Drives a distinct
    /// "unverified / user-created" marker and badge in the UI.
    public var isUserCreated: Bool { id.hasPrefix(Self.userIdPrefix) }

    /// Build a candidate `Experience` from raw user input. Trust-critical fields
    /// are forced to safe, unverified defaults — the user never scores their own
    /// place. Mirrors `createUserExperience` in packages/core/src/experience.ts.
    ///
    /// - Parameters:
    ///   - uuid: caller-supplied unique id (e.g. `UUID().uuidString`).
    ///   - now: creation timestamp; defaults to current date.
    public static func userDraft(
        uuid: String,
        title: String,
        oneLiner: String,
        category: ExperienceCategory,
        coordinates: [Double],
        cityCode: String,
        placeNameRomanized: String? = nil,
        placeNameLocal: String? = nil,
        addressHint: String? = nil,
        description: String = "",
        photoUrls: [String]? = nil,
        userTags: [String]? = nil,
        now: Date = Date()
    ) -> Experience {
        Experience(
            id: "\(userIdPrefix)\(uuid)",
            title: title,
            oneLiner: oneLiner,
            whyItMatters: description,
            category: category,
            location: ExperienceLocation(
                coordinates: coordinates,
                cityCode: cityCode,
                addressHint: addressHint,
                placeNameLocal: placeNameLocal,
                placeNameRomanized: placeNameRomanized,
                photoUrls: photoUrls
            ),
            bestTimes: [],
            durationMinutes: DurationRange(min: 30, max: 60),
            howTo: [],
            realInconveniences: [],
            soloScore: SoloScore(
                overall: 5,
                breakdown: SoloScore.Breakdown(
                    seatingFriendly: 5,
                    soloPatronRatio: 5,
                    staffPressure: 5,
                    soloPortioning: 5,
                    ambianceFit: 5,
                    safety: 5
                ),
                basedOnCount: 0
            ),
            sources: [InformationSource(type: .user, verifiedAt: now)],
            confidence: Confidence(
                level: 1,
                lastVerifiedAt: now,
                reason: "User-created, awaiting verification",
                signals: Confidence.Signals(
                    aiScrapeAgeDays: 0,
                    passiveGpsHits30d: 0,
                    activeReports30d: 0,
                    trustedVerifications: 0
                )
            ),
            nearbyExperienceIds: [],
            stats: Stats(completionCount: 0, averageRating: 0),
            status: .candidate,
            createdAt: now,
            updatedAt: now,
            userTags: userTags
        )
    }

    /// True only when the entry actually went through AI synthesis. The
    /// `skeletonExperience` fallback (network/quota failure, missing key)
    /// produces an OSM entry with no AI enrichment — its sources omit the
    /// "+ AI" attribution. Distinguishing the two prevents the detail view
    /// from labelling a raw, template-filled skeleton as "AI-generated".
    public var isAIEnriched: Bool {
        sources.contains { ($0.attribution ?? "").localizedCaseInsensitiveContains("AI") }
    }

    /// True for hand-curated seed entries: not user-created, not discovered via
    /// OSM/Amap, and without multi-source verification. Mirrors the `.curated`
    /// fallback in `trustBadgeLevel`. These cards carry human-written copy and
    /// scores, so the silent auto-upgrade path must never overwrite them.
    public var isCuratedSeed: Bool {
        guard !isUserCreated, !isFromOpenStreetMap else { return false }
        let distinctTypes = Set(sources.map(\.type))
        return distinctTypes.count < 2 && !distinctTypes.contains(.amap)
    }


}


extension Experience {
    init(id: String, title: String, category: ExperienceCategory, location: ExperienceLocation) {
        let now = Date()
        self.init(id: id, title: title, oneLiner: title, whyItMatters: title, category: category, location: location,
            bestTimes: [], durationMinutes: .init(min: 30, max: 60), howTo: [], realInconveniences: [],
            soloScore: .init(overall: 8, breakdown: .init(seatingFriendly: 8, soloPatronRatio: 8, staffPressure: 0, soloPortioning: 8, ambianceFit: 8, safety: 8), basedOnCount: 0),
            sources: [.init(type: .user, attribution: "© OpenStreetMap contributors", verifiedAt: now)],
            confidence: .init(level: 1, lastVerifiedAt: now, reason: "OpenStreetMap entry, no AI enrichment", signals: .init(aiScrapeAgeDays: 0, passiveGpsHits30d: 0, activeReports30d: 0, trustedVerifications: 0)),
            nearbyExperienceIds: [], stats: .init(completionCount: 0, averageRating: 0), status: .candidate, createdAt: now, updatedAt: now)
    }
}
@MainActor enum AIService {
    static func enrichedLocation(from poi: OverpassService.POI, cityCode: String) -> ExperienceLocation {
        .init(coordinates: [poi.lon, poi.lat], cityCode: cityCode)
    }

    static func skeletonExperience(from poi: OverpassService.POI, cityCode: String) -> Experience {
        let now = Date()
        let category = OverpassService.category(for: poi.tags)
        let displayName = poi.nameEn ?? poi.name
        let isAmapPOI = poi.tags["source"] == "amap"
        let isMapKitPOI = poi.tags["source"] == "mapkit"
        let breakdown = SoloScore.Breakdown(
            seatingFriendly: 0, soloPatronRatio: 0, staffPressure: 0,
            soloPortioning: 0, ambianceFit: 0, safety: 0
        )
        return Experience(
            id: "exp_osm_\(poi.osmId)",
            title: displayName,
            // The canonical POI container also carries Amap/MapKit results;
            // its synthetic osmId does not establish OpenStreetMap provenance.
            oneLiner: NSLocalizedString(
                isAmapPOI ? "explore.skeleton.oneLiner.amap"
                    : isMapKitPOI ? "explore.skeleton.oneLiner.mapkit" : "explore.skeleton.oneLiner",
                comment: "Generic POI tagline"
            ),
            whyItMatters: NSLocalizedString(
                isAmapPOI ? "explore.skeleton.why.amap" : "explore.skeleton.why",
                comment: "Generic POI rationale"
            ),
            category: category,
            location: enrichedLocation(from: poi, cityCode: cityCode),
            bestTimes: [],
            durationMinutes: .init(min: 30, max: 90),
            howTo: [],
            realInconveniences: [],
            soloScore: SoloScore(overall: 0, breakdown: breakdown, hint: NSLocalizedString("soloScore.unassessed", comment: "No assessment available"), basedOnCount: 0),
            sources: [
                // Same provenance-honesty fix as the AI-enriched path — the
                // skeleton fallback used to also mislabel Amap POIs as .user.
                InformationSource(
                    type: isAmapPOI ? .amap : .user,
                    url: isAmapPOI || isMapKitPOI
                        ? nil
                        : URL(string: "https://www.openstreetmap.org/node/\(poi.osmId)"),
                    attribution: isAmapPOI
                        ? "© AutoNavi (Amap)"
                        : isMapKitPOI ? "Apple Maps" : "© OpenStreetMap contributors",
                    verifiedAt: now
                )
            ],
            confidence: Confidence(
                level: 1,
                lastVerifiedAt: now,
                reason: isAmapPOI
                    ? "Amap entry, no AI enrichment"
                    : isMapKitPOI ? "Apple Maps entry, no AI enrichment" : "OpenStreetMap entry, no AI enrichment",
                signals: .init(aiScrapeAgeDays: 0, passiveGpsHits30d: 0, activeReports30d: 0, trustedVerifications: 0)
            ),
            nearbyExperienceIds: [],
            stats: .init(completionCount: 0, averageRating: 0),
            status: .candidate,
            createdAt: now,
            updatedAt: now
        )
    }

}

import Foundation

/// Pure decision rules for the same-ID discovery refresh path
/// (`ExperienceRepository.mergeDiscovered`). Given the stored experience and
/// an incoming discovery value sharing its id, the policy decides whether to
/// insert, refresh (with a fully merged value), or skip — and every skip is
/// attributed to an explicit `SkipReason`.
///
/// The policy is deliberately side-effect free: all SwiftData work lives in
/// `ExperienceRepository`, which writes the merged value the policy returns.
/// It never hands raw incoming values to the persistence layer.
///
/// ## What may be refreshed
/// Only rows that are unambiguously machine-generated by the known Explore
/// pipelines — see `isMachineGenerated(_:)` for the exact criterion.
/// Manual/user-created rows, curated seed copy, and field-visit or
/// human-verified content are never overwritten (`isHumanProtected(_:)`), and
/// rows whose provenance cannot be classified either way are left untouched
/// rather than risked.
public enum DiscoveryRefreshPolicy {
    // MARK: - Known machine signatures

    /// Source attribution strings written verbatim by the machine generation
    /// pipelines (`AIService` Edge/direct synthesis, `AIService.skeletonExperience`,
    /// and `CityExperienceFetcher`). A stored row is recognized as
    /// machine-generated only when every one of its sources carries one of
    /// these exact attributions on a machine source type.
    public static let automaticSourceAttributions: Set<String> = [
        "© OpenStreetMap contributors",
        "© OpenStreetMap contributors + AI",
        "© OpenStreetMap contributors + Foursquare/Apple Maps + AI",
        "© AutoNavi (Amap)",
        "© AutoNavi (Amap) + AI",
        "Apple Maps",
    ]

    /// Confidence `reason` strings written verbatim by the same pipelines.
    public static let machineConfidenceReasons: Set<String> = [
        "AI-synthesized via Edge Function, unverified",
        "AI-synthesized from OpenStreetMap, unverified",
        "AI-synthesized from OpenStreetMap + Foursquare/Apple Maps signals",
        "OpenStreetMap entry, no AI enrichment",
        "Amap entry, no AI enrichment",
        "Apple Maps entry, no AI enrichment",
    ]

    /// Why a same-ID incoming experience left the stored row untouched.
    public enum SkipReason: String, Equatable {
        /// The stored row is manual/user-created, curated, field-visited, or
        /// human-verified — its content must never be overwritten silently.
        case invalidCoordinates
        case protectedManual
        /// Provenance is neither clearly machine-generated nor clearly human:
        /// unknown attributions, empty sources, unrecognized confidence, or an
        /// id outside the `exp_osm_` machine namespace. Fails closed.
        case ambiguousIdentity
        /// The incoming value is a machine skeleton (offline/quota fallback)
        /// and the stored row carries richer content it must not erase.
        case skeletonDowngrade
        /// The incoming value is older than the stored row; a stale batch must
        /// not regress fresher content.
        case staleIncoming
    }

    /// The action to take for one incoming discovery experience.
    public enum Decision: Equatable {
        /// No stored row with this id — insert the incoming value as-is.
        case insert(Experience)
        /// Refresh the stored row with the policy-merged value.
        case refresh(merged: Experience)
        /// Leave the stored row untouched for the given reason.
        case skip(SkipReason)
    }

    // MARK: - Decision

    /// Decide how one incoming discovery experience relates to the stored row
    /// with the same id (`existing == nil` means no row yet).
    ///
    /// Reject invalid coordinates or unproven incoming provenance, then protect
    /// human content and apply freshness/richness checks to machine content.
    public static func decision(existing: Experience?, incoming: Experience) -> Decision {
        let coordinates = incoming.location.coordinates
        guard coordinates.count == 2, coordinates.allSatisfy(\.isFinite),
              (-180...180).contains(coordinates[0]), (-90...90).contains(coordinates[1]) else {
            return .skip(.invalidCoordinates)
        }
        if let existing, isHumanProtected(existing) { return .skip(.protectedManual) }
        guard isMachineGenerated(incoming), !isHumanProtected(incoming) else { return .skip(.ambiguousIdentity) }
        guard let existing else { return .insert(incoming) }
        guard existing.id == incoming.id else { return .skip(.ambiguousIdentity) }
        guard isMachineGenerated(existing) else {
            return .skip(.ambiguousIdentity)
        }
        if isMachineSkeleton(incoming), hasRichContent(existing) {
            return .skip(.skeletonDowngrade)
        }
        if incoming.updatedAt < existing.updatedAt {
            return .skip(.staleIncoming)
        }
        return .refresh(merged: merge(existing: existing, incoming: incoming))
    }

    // MARK: - Provenance predicates

    /// True when the source is one of the known machine-pipeline attributions:
    /// a machine source type (`.user`/`.amap` as written by the OSM/Amap
    /// pipelines) carrying one of `automaticSourceAttributions` verbatim.
    public static func isAutomaticSource(_ source: InformationSource) -> Bool {
        guard let attribution = source.attribution else { return false }
        switch source.type {
        case .user, .amap:
            return automaticSourceAttributions.contains(attribution)
        default:
            return false
        }
    }

    /// True when a human created or verified the stored row's content, so no
    /// automatic refresh may ever overwrite it: user-created ids
    /// (`exp_user_`), curated seed copy, any `field_visit` source (human field
    /// verification), or any trusted verification in the confidence signals.
    public static func isHumanProtected(_ experience: Experience) -> Bool {
        if experience.isUserCreated { return true }
        if experience.isCuratedSeed { return true }
        if experience.sources.contains(where: { $0.type == .fieldVisit }) { return true }
        return experience.confidence.signals.trustedVerifications > 0
    }

    /// True when every provenance marker on the row is explained by the known
    /// machine-generation pipelines:
    ///   1. the id lives in the `exp_osm_` machine namespace;
    ///   2. sources are non-empty and **every** source carries a known
    ///      automatic attribution on a machine source type;
    ///   3. confidence has zero trusted verifications and is machine-grade:
    ///      either a known machine reason, or the structural machine signature
    ///      (level ≤ 1 with no attached real-world signals).
    ///
    /// Anything else — an unrecognized attribution, an empty source list, a
    /// non-OSM id, or confidence we cannot attribute to a machine pipeline —
    /// is *ambiguous*: we neither treat it as safe to rewrite nor as human
    /// work, and skip the refresh (`.ambiguousIdentity`).
    public static func isMachineGenerated(_ experience: Experience) -> Bool {
        guard experience.isFromOpenStreetMap else { return false }
        guard !experience.sources.isEmpty else { return false }
        guard experience.sources.allSatisfy(isAutomaticSource) else { return false }
        guard experience.confidence.signals.trustedVerifications == 0 else { return false }
        if machineConfidenceReasons.contains(experience.confidence.reason) { return true }
        return experience.confidence.level <= 1 && experience.confidence.signals.totalCount == 0
    }

    // MARK: - Richness predicates

    /// True for the offline/quota-fallback skeleton
    /// (`AIService.skeletonExperience`): no AI enrichment, an unassessed
    /// (zero) Solo Score, and no timing, guidance, or warning content.
    public static func isMachineSkeleton(_ experience: Experience) -> Bool {
        !experience.isAIEnriched
            && experience.soloScore.overall <= 0
            && experience.bestTimes.isEmpty
            && experience.howTo.isEmpty
            && experience.realInconveniences.isEmpty
    }

    /// True when the row carries content a skeleton must never erase: AI copy,
    /// an assessed Solo Score, timing/guidance/warnings, or highlights.
    public static func hasRichContent(_ experience: Experience) -> Bool {
        experience.isAIEnriched
            || experience.soloScore.overall > 0
            || !experience.bestTimes.isEmpty
            || !experience.howTo.isEmpty
            || !experience.realInconveniences.isEmpty
            || !experience.highlights.isEmpty
    }

    // MARK: - Merge

    /// Build the merged value a refresh writes over `existing`. Fresh
    /// machine-generated facts win where they are allowed to win; user and
    /// community evidence is always retained. Field rules:
    ///
    /// | Field | Rule |
    /// | --- | --- |
    /// | id, createdAt, stats, status, userTags | kept from `existing` |
    /// | title, oneLiner, whyItMatters | `incoming`, falling back to `existing` when empty |
    /// | category | `incoming` (`.hidden` never overwrites a known category) |
    /// | coordinates, cityCode, names, address | `incoming`, per-field fallback to `existing` |
    /// | rating / hours / price / website / phone | `incoming`; unknown clears old machine facts |
    /// | photoUrls | union — `existing` order first, then new `incoming` URLs |
    /// | bestTimes | `incoming` verbatim — an empty list clears stale unsupported windows |
    /// | durationMinutes | `incoming` |
    /// | howTo, realInconveniences, nearbyExperienceIds | `incoming`; empty clears old machine facts |
    /// | soloScore | `existing` when it has community evidence (`basedOnCount > 0`), else `incoming` |
    /// | sources | `incoming` plus retained human (non-automatic) `existing` sources |
    /// | confidence | `existing` when it carries real-world signals, else `incoming` |
    /// | categoryHighlights | `incoming` when non-empty, else `existing` |
    /// | updatedAt | `incoming` |
    public static func merge(existing: Experience, incoming: Experience) -> Experience {
        let retainedHighlights: [CategoryHighlight]?
        if let incomingHighlights = incoming.categoryHighlights, !incomingHighlights.isEmpty {
            retainedHighlights = incomingHighlights
        } else {
            retainedHighlights = existing.categoryHighlights
        }
        let retainedCategory: ExperienceCategory =
            incoming.category == .hidden && existing.category != .hidden ? existing.category : incoming.category
        return Experience(
            id: existing.id,
            title: incoming.title.isEmpty ? existing.title : incoming.title,
            oneLiner: incoming.oneLiner.isEmpty ? existing.oneLiner : incoming.oneLiner,
            whyItMatters: incoming.whyItMatters.isEmpty ? existing.whyItMatters : incoming.whyItMatters,
            category: retainedCategory,
            location: mergedLocation(existing: existing.location, incoming: incoming.location),
            bestTimes: incoming.bestTimes,
            durationMinutes: incoming.durationMinutes,
            howTo: incoming.howTo,
            realInconveniences: incoming.realInconveniences,
            soloScore: existing.soloScore.basedOnCount > 0 ? existing.soloScore : incoming.soloScore,
            sources: mergedSources(existing: existing, incoming: incoming),
            confidence: mergedConfidence(existing: existing, incoming: incoming),
            nearbyExperienceIds: incoming.nearbyExperienceIds,
            stats: existing.stats,
            status: existing.status,
            createdAt: existing.createdAt,
            updatedAt: incoming.updatedAt,
            userTags: existing.userTags ?? incoming.userTags,
            categoryHighlights: retainedHighlights
        )
    }

    // MARK: - Merge helpers

    /// A complete synthesis replaces machine facts, including unknown values.
    /// Skeleton downgrade is rejected before this merge; user photos survive.
    private static func mergedLocation(
        existing: ExperienceLocation,
        incoming: ExperienceLocation
    ) -> ExperienceLocation {
        return ExperienceLocation(
            coordinates: incoming.coordinates,
            cityCode: incoming.cityCode.isEmpty ? existing.cityCode : incoming.cityCode,
            addressHint: incoming.addressHint,
            placeNameLocal: incoming.placeNameLocal,
            placeNameRomanized: incoming.placeNameRomanized,
            rating: incoming.rating,
            openingHours: incoming.openingHours,
            priceLevel: incoming.priceLevel,
            website: incoming.website,
            phone: incoming.phone,
            photoUrls: mergedPhotoUrls(existing: existing.photoUrls, incoming: incoming.photoUrls)
        )
    }

    /// Photo union: existing URLs (including user-added "real" photos) keep
    /// their order and are never dropped; new incoming URLs are appended
    /// de-duplicated.
    private static func mergedPhotoUrls(existing: [String]?, incoming: [String]?) -> [String]? {
        guard existing != nil || incoming != nil else { return nil }
        var seen: Set<String> = []
        var merged: [String] = []
        for url in (existing ?? []) + (incoming ?? []) {
            if seen.insert(url).inserted {
                merged.append(url)
            }
        }
        return merged
    }

    /// Fresh automatic sources replace their stale automatic counterparts;
    /// any human (non-automatic) source on the stored row is trustworthy
    /// evidence and is always retained.
    private static func mergedSources(existing: Experience, incoming: Experience) -> [InformationSource] {
        var seen: Set<String> = []
        var merged: [InformationSource] = []
        let retained = existing.sources.filter { !isAutomaticSource($0) }
        for source in incoming.sources + retained {
            let key = "\(source.type.rawValue)|\(source.url?.absoluteString ?? "")|\(source.attribution ?? "")"
            if seen.insert(key).inserted {
                merged.append(source)
            }
        }
        return merged
    }

    /// Confidence carrying real-world signals (reports, GPS hits, trusted
    /// verifications) is human/community evidence and survives the refresh; a
    /// bare machine signature yields to the fresh one.
    private static func mergedConfidence(existing: Experience, incoming: Experience) -> Confidence {
        existing.confidence.signals.totalCount > 0 ? existing.confidence : incoming.confidence
    }
}

/// Outcome of `ExperienceRepository.mergeDiscovered(_:)`: which ids were newly
/// inserted, which stored rows were refreshed in place, and which were left
/// untouched with the policy reason. Callers use `insertedIDs` for new-only
/// badges/toasts and reload their visible state when `didChangeStore` is true.
public struct DiscoveryMergeResult: Equatable {
    /// Ids with no stored row that were inserted from the batch.
    public let insertedIDs: Set<String>
    /// Ids whose stored row was refreshed with merged content (count stays 1).
    public let refreshedIDs: Set<String>
    /// Ids left untouched, keyed by the policy reason for skipping.
    public let skipped: [String: DiscoveryRefreshPolicy.SkipReason]

    /// Number of newly inserted rows — the "new discoveries" count.
    public var insertedCount: Int { insertedIDs.count }

    /// Number of stored rows refreshed in place.
    public var refreshedCount: Int { refreshedIDs.count }

    /// True when the store changed (inserted or refreshed), i.e. when callers
    /// should reload their visible experiences.
    public var didChangeStore: Bool { !insertedIDs.isEmpty || !refreshedIDs.isEmpty }

    /// Build a result; empty sets are the natural default for a no-op batch.
    public init(
        insertedIDs: Set<String> = [],
        refreshedIDs: Set<String> = [],
        skipped: [String: DiscoveryRefreshPolicy.SkipReason] = [:]
    ) {
        self.insertedIDs = insertedIDs
        self.refreshedIDs = refreshedIDs
        self.skipped = skipped
    }
}

public enum TrustBadge {
    public enum Level: Equatable {
        /// ≥2 distinct data sources agreed on this place. Strongest signal.
        case verified(sourceCount: Int)
        /// AutoNavi (高德) is the authoritative base. Mainland-China coverage.
        case amap
        /// Apple's live point-of-interest search, without AI enrichment.
        case appleMaps
        /// OpenStreetMap contributor data.
        case osm
        /// The user registered this place themselves; unverified.
        case userCreated
        /// Curated seed entry — the app shipped with it.
        case curated

        var label: String {
            switch self {
            case .verified(let n):
                return String(
                    format: NSLocalizedString("trustBadge.verified", comment: "%d sources"),
                    n
                )
            case .amap:        return NSLocalizedString("trustBadge.amap", comment: "AutoNavi (Amap)")
            case .appleMaps:   return NSLocalizedString("location.openIn.apple", comment: "Apple Maps")
            case .osm:         return NSLocalizedString("trustBadge.osm", comment: "OpenStreetMap")
            case .userCreated: return NSLocalizedString("trustBadge.user", comment: "User-added")
            case .curated:     return NSLocalizedString("trustBadge.curated", comment: "Curated")
            }
        }




    }
}
extension Experience {
    var trustBadgeLevel: TrustBadge.Level {
        let distinctSources = Set(sources.map(\.type))

        if distinctSources.count >= 2 {
            return .verified(sourceCount: distinctSources.count)
        }
        if distinctSources.contains(.amap) {
            return .amap
        }
        if isUserCreated {
            return .userCreated
        }
        if sources.contains(where: { $0.attribution == "Apple Maps" }) {
            return .appleMaps
        }
        if isFromOpenStreetMap {
            return .osm
        }
        return .curated
    }
}


import Foundation
import CoreLocation


public enum OverpassService {
    public struct POI: Codable, Hashable, Identifiable {
        public let osmId: Int64
        public let name: String
        public let nameEn: String?
        public let lat: Double
        public let lon: Double
        public let tags: [String: String]

        public var id: Int64 { osmId }

        public var coordinate: CLLocationCoordinate2D {
            CLLocationCoordinate2D(latitude: lat, longitude: lon)
        }

        public init(osmId: Int64, name: String, nameEn: String?, lat: Double, lon: Double, tags: [String: String]) {
            self.osmId = osmId
            self.name = name
            self.nameEn = nameEn
            self.lat = lat
            self.lon = lon
            self.tags = tags
        }
    }
    public static func category(for tags: [String: String]) -> ExperienceCategory {
        if let amenity = tags["amenity"] {
            switch amenity {
            case "cafe", "ice_cream":
                return .coffee
            case "restaurant", "fast_food", "food_court":
                return .food
            case "bar", "pub":
                return .nightlife
            case "library", "coworking_space":
                return .work
            case "spa":
                return .wellness
            default:
                break
            }
        }
        if let shop = tags["shop"] {
            switch shop {
            case "coffee", "tea":
                return .coffee
            case "books":
                return .work
            default:
                break
            }
        }
        if let tourism = tags["tourism"] {
            switch tourism {
            case "viewpoint":
                return .hidden
            case "attraction", "artwork", "gallery", "museum":
                return .culture
            case "zoo", "aquarium":
                return .nature
            default:
                break
            }
        }
        if let leisure = tags["leisure"] {
            switch leisure {
            case "park", "garden", "nature_reserve":
                return .nature
            case "fitness_centre":
                return .wellness
            default:
                break
            }
        }
        if tags["natural"] != nil {
            return .nature
        }
        return .hidden
    }
}

enum EnrichmentAgent { public static let progressiveRadii: [Int] = [1_500, 3_000, 6_000, 12_000] }
enum Authorization { case notDetermined, denied, authorizedWhenInUse, authorizedAlways }
@MainActor final class LocationService {
    var authorizationStatus = Authorization.notDetermined
    var currentLocation: CLLocation?
}

@MainActor final class MapViewModel {
    static let defaultCenter = CLLocationCoordinate2D(latitude: 18.7877, longitude: 98.9938)
    static let knownCityCenters = ["tokyo": CLLocationCoordinate2D(latitude: 35.6817, longitude: 139.7708)]
    static let cityCodeAliases: [String: String] = [:]
    var selectedCity: String? = nil
    var cityPickedExplicitlyThisSession = false
    var lastVisibleMapCenter: CLLocationCoordinate2D? = nil
    var customCoordinates: CLLocationCoordinate2D? = nil
    var availableCities: [(code: String, name: String, center: CLLocationCoordinate2D)] = []
    let locationService = LocationService()
    var visibleExperiences: [Experience] = []
    var allExperiences: [Experience] = []
    var lastExploreAddedCount = 0
    var genericRequests: [CLLocationCoordinate2D] = []
    var isSearchingWeb = false
    static func cityCodeMatches(_ lhs: String, selected rhs: String) -> Bool { lhs == rhs }
    static func cityCode(for coordinate: CLLocationCoordinate2D) -> String { "geo_\(coordinate.longitude)_\(coordinate.latitude)" }
    func exploreProgressively(at coordinate: CLLocationCoordinate2D, startingRadiusMeters: Int?, category: ExperienceCategory?, filter: ExperienceFilter?) async { genericRequests.append(coordinate) }
    func exploreNearby(at coordinate: CLLocationCoordinate2D, radiusMeters: Int, category: ExperienceCategory?) async { genericRequests.append(coordinate) }
    func mergeDiscoveryBatch(_ experiences: [Experience]) -> DiscoveryMergeResult {
        var inserted: Set<String> = []
        for value in experiences {
            switch DiscoveryRefreshPolicy.decision(existing: allExperiences.first { $0.id == value.id }, incoming: value) {
            case .insert(let added): allExperiences.append(added); visibleExperiences.append(added); inserted.insert(added.id)
            case .refresh, .skip: break
            }
        }
        return .init(insertedIDs: inserted)
    }

    var agentSearchOrigin: (coordinate: CLLocationCoordinate2D, source: String)? {
        func valid(_ coordinate: CLLocationCoordinate2D) -> Bool {
            coordinate.latitude.isFinite && coordinate.longitude.isFinite && CLLocationCoordinate2DIsValid(coordinate)
        }
        if let center = lastVisibleMapCenter, valid(center) { return (center, "map_viewport") }
        if let coordinate = customCoordinates, valid(coordinate) { return (coordinate, "map_selection") }
        if cityPickedExplicitlyThisSession, let city = selectedCity {
            let center = Self.knownCityCenters[city]
                ?? Self.cityCodeAliases[city.lowercased()].flatMap { Self.knownCityCenters[$0] }
                ?? Self.knownCityCenters[city.uppercased()]
                ?? Self.knownCityCenters[city.lowercased()]
                ?? availableCities.first(where: { Self.cityCodeMatches($0.code, selected: city) })?.center
            if let center, valid(center) { return (center, "selected_city") }
        }
        if locationService.authorizationStatus == .authorizedWhenInUse || locationService.authorizationStatus == .authorizedAlways,
           let coordinate = locationService.currentLocation?.coordinate, valid(coordinate) {
            return (coordinate, "authorized_location")
        }
        return nil
    }

}

private protocol QualityArgsProvider {
    var categories: [String]? { get }
    var solo_score_min: Double? { get }
    var rating_min: Double? { get }
    var ambiance_min: Double? { get }
}


import Foundation

// MARK: - ExperienceFilter

/// Structured filter derived from natural-language queries.
///
/// Quality dimensions (US-017):
/// - ratingMin: minimum provider rating (0–10) from location.rating
/// - ambianceMin: minimum ambianceFit breakdown score (0–10)
/// - quietness: true = high seatingFriendly + low staffPressure
/// - soloFriendly: true = high soloPatronRatio + high soloPortioning
/// - priceMax: maximum price level (1–4)
///
/// Originally lived alongside the now-removed QueryAgent. Promoted to
/// `Models/` because `MapViewModel` and `VoiceAgentToolRouter` consume
/// the predicate (`matches(_:)`) directly.
public struct ExperienceFilter: Sendable, Equatable {
    public let category: String?
    public let maxDistanceMeters: Double?
    public let openNow: Bool
    public let soloScoreMin: Double?
    public let ratingMin: Double?
    public let ambianceMin: Double?
    public let quietness: Bool
    public let soloFriendly: Bool
    public let priceMax: Double?

    public init(
        category: String? = nil,
        maxDistanceMeters: Double? = nil,
        openNow: Bool = false,
        soloScoreMin: Double? = nil,
        ratingMin: Double? = nil,
        ambianceMin: Double? = nil,
        quietness: Bool = false,
        soloFriendly: Bool = false,
        priceMax: Double? = nil
    ) {
        self.category = category
        self.maxDistanceMeters = maxDistanceMeters
        self.openNow = openNow
        self.soloScoreMin = soloScoreMin
        self.ratingMin = ratingMin
        self.ambianceMin = ambianceMin
        self.quietness = quietness
        self.soloFriendly = soloFriendly
        self.priceMax = priceMax
    }

    /// Returns true when `experience` satisfies all active filter dimensions.
    /// Dimensions with nil / false values are skipped (inactive).
    public func matches(_ experience: Experience) -> Bool {
        if let cat = category, !cat.isEmpty {
            guard experience.category.rawValue == cat else { return false }
        }
        if let rMin = ratingMin {
            guard let rating = experience.location.rating, rating >= rMin else { return false }
        }
        if let priceMax, let price = experience.location.priceLevel {
            guard price <= priceMax else { return false }
        }
        if let score = soloScoreMin {
            guard experience.soloScore.overall >= score else { return false }
        }
        if let ambMin = ambianceMin {
            guard experience.soloScore.breakdown.ambianceFit >= ambMin else { return false }
        }
        // quietness: seatingFriendly ≥ 7 AND staffPressure ≤ 3
        if quietness {
            let bd = experience.soloScore.breakdown
            guard bd.seatingFriendly >= 7.0 && bd.staffPressure <= 3.0 else { return false }
        }
        // soloFriendly: soloPatronRatio ≥ 7 AND soloPortioning ≥ 7
        if soloFriendly {
            let bd = experience.soloScore.breakdown
            guard bd.soloPatronRatio >= 7.0 && bd.soloPortioning >= 7.0 else { return false }
        }
        return true
    }
}

@MainActor final class VoiceAgentToolRouter {
    enum RouterError: Error { case invalidArguments(tool: String, reason: String); case dependencyUnavailable(tool: String, dependency: String, hint: String); case underlying(tool: String, message: String) }
    enum ToolEffect { case experiences([Experience]) }
    var lastEffect: ToolEffect?
    var isSearchingPlaces = false
    private lazy var placeSearchService = MapKitPOIService()
    let vm: MapViewModel
    init(vm: MapViewModel) { self.vm = vm }
    private static let maxCardExperiences = 6
    private static let maxAutoExpandStages = 6
    private func requireMapVM(tool: String) throws -> MapViewModel { vm }
    private func autoExpandUntilResults(vm: MapViewModel) async -> (stagesExpanded: Int, exhausted: Bool) { (0, false) }

    private struct ExploreNearbyArgs: Decodable, QualityArgsProvider {
        let latitude: Double?
        let longitude: Double?
        let radius_meters: Int?
        let categories: [String]?
        let solo_score_min: Double?
        let rating_min: Double?
        let ambiance_min: Double?
        let progressive: Bool?
    }
    private func executeExploreNearby(args: String) async throws -> String {
        let parsed: ExploreNearbyArgs = try Self.decode(args, tool: "explore_nearby")
        let vm = try requireMapVM(tool: "explore_nearby")
        let origin = try resolveSearchOrigin(
            latitude: parsed.latitude, longitude: parsed.longitude, vm: vm, tool: "explore_nearby"
        )
        let coord = origin.coordinate
        let useProgressive = parsed.progressive ?? true
        // Explicit radius_meters overrides the progressive starting ring.
        let radius = parsed.radius_meters ?? 3000
        let category = parsed.categories?.compactMap(ExperienceCategory.init(rawValue:)).first
        // Snapshot the visible set so we can diff which places this explore added
        // and surface them as inline chat cards (the agent no longer jumps the map).
        let before = Set(vm.visibleExperiences.map(\.id))
        if useProgressive {
            await vm.exploreProgressively(
                at: coord,
                startingRadiusMeters: parsed.radius_meters,
                category: category,
                filter: Self.buildFilter(from: parsed)
            )
        } else {
            await vm.exploreNearby(at: coord, radiusMeters: radius, category: category)
        }
        // If the first ring came up empty, don't surrender — widen the search
        // automatically (the agent should compile the wider surroundings rather
        // than reply "found nothing"). Only meaningful on the progressive path,
        // which owns the ring ladder.
        var stagesExpanded = 0
        var ladderExhausted = false
        if useProgressive {
            let outcome = await autoExpandUntilResults(vm: vm)
            stagesExpanded = outcome.stagesExpanded
            ladderExhausted = outcome.exhausted
        }
        // Re-diff against the original snapshot so cards reflect everything the
        // auto-expansion surfaced, not just the (empty) first ring.
        recordAddedEffect(before: before, vm: vm)
        return Self.successJSON([
            "added_count": vm.lastExploreAddedCount,
            "radius_meters": radius,
            "progressive": useProgressive,
            "auto_expanded_stages": stagesExpanded,
            "search_exhausted": ladderExhausted,
            "origin_source": origin.source,
        ])
    }
    private func recordAddedEffect(before: Set<String>, vm: MapViewModel) {
        let added = vm.visibleExperiences.filter { !before.contains($0.id) }
        guard !added.isEmpty else { return }
        lastEffect = .experiences(Array(added.prefix(Self.maxCardExperiences)))
    }
    private struct SearchPlacesArgs: Decodable, QualityArgsProvider {
        let query: String
        let latitude: Double?
        let longitude: Double?
        let radius_meters: Int?
        let categories: [String]?
        let solo_score_min: Double?
        let rating_min: Double?
        let ambiance_min: Double?
        let progressive: Bool?
    }
    private func executeSearchPlaces(args: String) async throws -> String {
        let parsed: SearchPlacesArgs = try Self.decode(args, tool: "search_places")
        let vm = try requireMapVM(tool: "search_places")
        let query = parsed.query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else {
            throw RouterError.invalidArguments(tool: "search_places", reason: "query must not be empty")
        }
        let origin = try resolveSearchOrigin(
            latitude: parsed.latitude, longitude: parsed.longitude, vm: vm, tool: "search_places"
        )
        let useProgressive = parsed.progressive ?? true
        let radius = parsed.radius_meters ?? 2000
        guard (500...100_000).contains(radius) else {
            throw RouterError.invalidArguments(tool: "search_places", reason: "radius_meters must be between 500 and 100000")
        }
        guard !isSearchingPlaces, !vm.isSearchingWeb else {
            throw RouterError.dependencyUnavailable(
                tool: "search_places", dependency: "place search",
                hint: "A place search is already running. Wait for it to finish before searching again."
            )
        }
        isSearchingPlaces = true
        defer { isSearchingPlaces = false }
        let searchCity = vm.selectedCity
        let filter = Self.buildFilter(from: parsed)
        let radii = [radius] + (useProgressive ? EnrichmentAgent.progressiveRadii.filter { $0 > radius } : [])
        var providerHitIDs: Set<String> = []

        for (stage, searchRadius) in radii.enumerated() {
            let pois: [OverpassService.POI]
            do {
                pois = try await placeSearchService.search(
                    query: query, near: origin.coordinate, radiusMeters: searchRadius
                )
                try Task.checkCancellation()
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                throw RouterError.underlying(tool: "search_places", message: "Apple Maps place search failed; no completed search results are available.")
            }
            if origin.source != "explicit_coordinates" {
                guard vm.selectedCity == searchCity else {
                    throw RouterError.underlying(tool: "search_places", message: "The map city changed while searching. Old search results were discarded.")
                }
                guard let current = vm.agentSearchOrigin,
                      current.source == origin.source,
                      current.coordinate.latitude == origin.coordinate.latitude,
                      current.coordinate.longitude == origin.coordinate.longitude else {
                    throw RouterError.underlying(tool: "search_places", message: "The map area changed while searching. Old search results were discarded.")
                }
            }
            // Keep provider facts and unknown quality explicit. Existing rich
            // entries are the authority for filtering and cards on repeat hits.
            let existing = Dictionary(uniqueKeysWithValues: vm.allExperiences.map { ($0.id, $0) })
            let discovered = pois.map {
                AIService.skeletonExperience(from: $0, cityCode: MapViewModel.cityCode(for: origin.coordinate))
            }
            providerHitIDs.formUnion(discovered.map(\.id))
            let candidates = discovered.filter { filter.matches(existing[$0.id] ?? $0) }
            let merged = vm.mergeDiscoveryBatch(candidates)
            let canonical = Dictionary(uniqueKeysWithValues: vm.allExperiences.map { ($0.id, $0) })
            var seen: Set<String> = []
            let matches = candidates.compactMap { canonical[$0.id] }
                .filter { seen.insert($0.id).inserted }
            // A provider hit that fails the requested category/quality does
            // not satisfy the search. Keep the same query in the next ring.
            guard !matches.isEmpty || stage == radii.count - 1 else { continue }
            let cards = Array(matches.prefix(Self.maxCardExperiences))
            if !cards.isEmpty { lastEffect = .experiences(cards) }
            return Self.successJSON([
                "query": query,
                "provider": "apple_maps",
                "origin_source": origin.source,
                "found_count": providerHitIDs.count,
                "eligible_count": matches.count,
                "added_count": merged.insertedCount,
                "radius_meters": searchRadius,
                "progressive": useProgressive,
                "auto_expanded_stages": stage,
                "search_exhausted": matches.isEmpty && useProgressive,
                "quality_note": "New Apple Maps places have unassessed solo quality and may have no rating; quality constraints are never inferred.",
                "results": cards.map { ["experience_id": $0.id, "title": $0.title] },
            ])
        }
        throw RouterError.underlying(tool: "search_places", message: "No search radius was available.")
    }
    private static func buildFilter<T>(from args: T) -> ExperienceFilter where T: QualityArgsProvider {
        ExperienceFilter(
            category: args.categories?.compactMap(ExperienceCategory.init(rawValue:)).first?.rawValue,
            soloScoreMin: args.solo_score_min,
            ratingMin: args.rating_min,
            ambianceMin: args.ambiance_min
        )
    }
    private static func decode<T: Decodable>(_ argsJSON: String, tool: String) throws -> T {
        guard let data = argsJSON.data(using: .utf8) else {
            throw RouterError.invalidArguments(tool: tool, reason: "arguments not valid UTF-8")
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw RouterError.invalidArguments(
                tool: tool, reason: error.localizedDescription
            )
        }
    }
    private static func successJSON(_ fields: [String: Any]) -> String {
        var payload = fields
        payload["ok"] = true
        if let data = try? JSONSerialization.data(withJSONObject: payload),
           let s = String(data: data, encoding: .utf8) {
            return s
        }
        return #"{"ok":true}"#
    }
    private func resolveSearchOrigin(
        latitude: Double?, longitude: Double?, vm: MapViewModel, tool: String
    ) throws -> (coordinate: CLLocationCoordinate2D, source: String) {
        switch (latitude, longitude) {
        case let (.some(latitude), .some(longitude)):
            let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            guard latitude.isFinite, longitude.isFinite, CLLocationCoordinate2DIsValid(coordinate) else {
                throw RouterError.invalidArguments(tool: tool, reason: "latitude and longitude must be valid finite coordinates")
            }
            return (coordinate, "explicit_coordinates")
        case (.none, .none):
            guard let origin = vm.agentSearchOrigin else {
                throw RouterError.invalidArguments(tool: tool, reason: "No map area or authorized location is available. Ask the user to choose an area or enable location; do not guess their coordinates")
            }
            return origin
        default:
            throw RouterError.invalidArguments(tool: tool, reason: "provide both latitude and longitude, or omit both to use the current map area")
        }
    }

    func liveSearch(_ args: String) async throws -> String { try await executeSearchPlaces(args: args) }
}
@main struct LiveEval {
    @MainActor static func main() async {
        let started = Date()
        let data = FileHandle.standardInput.readDataToEndOfFile()
        do {
            let input = try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
            let args = input["args"] as? [String: Any] ?? [:]
            if input["operation"] as? String == "raw_comparison" {
                let center = CLLocationCoordinate2D(latitude: 35.6817, longitude: 139.7708)
                let space = MapKitCoordinateSpace.shared
                try await space.prepare(near: center)
                guard let searchCenter = space.searchCoordinate(center) else { throw MapKitCoordinateSpace.CalibrationError.unavailable }
                let request = MKLocalSearch.Request()
                request.naturalLanguageQuery = "東京駅"
                request.region = .init(center: searchCenter, latitudinalMeters: 4000, longitudinalMeters: 4000)
                request.resultTypes = .pointOfInterest
                if #available(macOS 15.0, *) { request.regionPriority = .required }
                let response = try await MKLocalSearch(request: request).start()
                for item in response.mapItems {
                    try await space.prepare(near: item.placemark.coordinate, countryCode: item.placemark.isoCountryCode)
                }
                let mapped = response.mapItems.compactMap { MapKitPOIService.poi(from: $0) }
                let filtered = MapKitPOIService.withinRadius(mapped, center: center, meters: 2000)
                let rows: [[String: Any]] = response.mapItems.prefix(6).map { item in
                    ["name": item.name ?? "", "latitude": item.placemark.coordinate.latitude,
                     "longitude": item.placemark.coordinate.longitude, "country": item.placemark.isoCountryCode ?? "",
                     "category": item.pointOfInterestCategory?.rawValue ?? ""]
                }
                let value: [String: Any] = ["ok": true, "query": "東京駅", "raw_map_items": response.mapItems.count,
                    "mapped_pois": mapped.count, "within_radius_pois": filtered.count, "raw_rows": rows,
                    "elapsed_ms": Int(Date().timeIntervalSince(started) * 1000)]
                print(String(decoding: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]), as: UTF8.self))
                return
            }
            let raw = String(decoding: try JSONSerialization.data(withJSONObject: args), as: UTF8.self)
            let vm = MapViewModel()
            vm.selectedCity = "tokyo"
            vm.cityPickedExplicitlyThisSession = true
            vm.lastVisibleMapCenter = .init(latitude: 35.6958, longitude: 139.7585)
            let router = VoiceAgentToolRouter(vm: vm)
            let searching = Task { @MainActor in try await router.liveSearch(raw) }
            if input["operation"] as? String == "change_city_during_search" {
                try await Task.sleep(for: .milliseconds(10))
                vm.selectedCity = "lisbon"
                vm.lastVisibleMapCenter = .init(latitude: 38.7223, longitude: -9.1393)
            }
            let rawResult = try await searching.value
            let parsed = try JSONSerialization.jsonObject(with: Data(rawResult.utf8))
            let records: [[String: Any]] = vm.allExperiences.map { e in
                ["id": e.id, "name": e.title, "coordinates": e.location.coordinates,
                 "category": e.category.rawValue, "rating": e.location.rating as Any? ?? NSNull(),
                 "solo_score": e.soloScore.overall, "confidence_level": e.confidence.level,
                 "confidence_reason": e.confidence.reason,
                 "sources": e.sources.map { ["title": $0.attribution ?? "", "url": $0.url?.absoluteString ?? ""] }]
            }
            let value: [String: Any] = ["ok": true, "elapsed_ms": Int(Date().timeIntervalSince(started) * 1000),
                "tool_result": parsed, "actual_experience_records": records,
                "vm_boundary": "isolated in-memory QA fixture; no iOS persistence or UI",
                "provider_boundary": "production MapKitPOIService and coordinate sources, real macOS Apple Maps SDK"]
            print(String(decoding: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]), as: UTF8.self))
        } catch {
            let value: [String: Any] = ["ok": false, "error": String(describing: error),
                                      "elapsed_ms": Int(Date().timeIntervalSince(started) * 1000)]
            print(String(decoding: try! JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]), as: UTF8.self))
        }
    }
}

import Foundation
import CoreLocation

/// Offline provider-routing boundary, not a survey/navigation boundary.
/// Natural Earth 1:10m Admin 0 Countries, public domain. The bundled GeoJSON
/// records the upstream SHA-256; missing/invalid data fails closed.
enum MainlandChinaBoundary {
    private struct Collection: Decodable { let features: [Feature] }
    private struct Feature: Decodable { let geometry: Geometry; let properties: Properties? }
    private struct Properties: Decodable { let region: String? }
    private struct Geometry: Decodable { let coordinates: [[[[Double]]]] }

    private struct Polygon {
        let rings: [[[Double]]]
        let minLon: Double, maxLon: Double, minLat: Double, maxLat: Double
        init(_ rings: [[[Double]]]) {
            self.rings = rings
            let outer = rings.first ?? []
            let lon = outer.compactMap { $0.first }, lat = outer.compactMap { $0.count > 1 ? $0[1] : nil }
            minLon = lon.min() ?? .infinity; maxLon = lon.max() ?? -.infinity
            minLat = lat.min() ?? .infinity; maxLat = lat.max() ?? -.infinity
        }
        func contains(_ c: CLLocationCoordinate2D) -> Bool {
            guard minLon <= maxLon, minLat <= maxLat, (minLon...maxLon).contains(c.longitude), (minLat...maxLat).contains(c.latitude),
                  let outer = rings.first, MainlandChinaBoundary.contains(c, ring: outer) else { return false }
            return !rings.dropFirst().contains { MainlandChinaBoundary.contains(c, ring: $0) }
        }
    }
    private static let polygons: [Polygon] = {
        let url = Bundle.main.url(forResource: "mainland_china_boundary", withExtension: "json")
            ?? Bundle.main.url(forResource: "mainland_china_boundary", withExtension: "json", subdirectory: "JSON")
        guard let url, let data = try? Data(contentsOf: url),
              let collection = try? JSONDecoder().decode(Collection.self, from: data) else { return [] }
        return collection.features.flatMap { $0.geometry.coordinates }.map(Polygon.init)
    }()

    private static let foreignPolygons: [Polygon] = {
        let url = Bundle.main.url(forResource: "mapkit_foreign_land", withExtension: "geojson")
            ?? Bundle.main.url(forResource: "mapkit_foreign_land", withExtension: "geojson", subdirectory: "JSON")
        guard let url, let data = try? Data(contentsOf: url),
              let collection = try? JSONDecoder().decode(Collection.self, from: data) else { return [] }
        return collection.features.flatMap { $0.geometry.coordinates }.map(Polygon.init)
    }()

    private static let specialRegions: [(String, [Polygon])] = {
        let url = Bundle.main.url(forResource: "mapkit_special_regions", withExtension: "geojson")
            ?? Bundle.main.url(forResource: "mapkit_special_regions", withExtension: "geojson", subdirectory: "JSON")
        guard let url, let data = try? Data(contentsOf: url),
              let collection = try? JSONDecoder().decode(Collection.self, from: data) else { return [] }
        return collection.features.compactMap { feature in
            guard let region = feature.properties?.region else { return nil }
            return (region, feature.geometry.coordinates.map(Polygon.init))
        }
    }()

    static func specialRegion(_ coordinate: CLLocationCoordinate2D) -> String? {
        specialRegions.first { $0.1.contains { $0.contains(coordinate) } }?.0
    }

    /// Positive evidence of foreign land; missing geometry never proves WGS84.
    static func isForeignLand(_ coordinate: CLLocationCoordinate2D) -> Bool {
        guard CLLocationCoordinate2DIsValid(coordinate) else { return false }
        return foreignPolygons.contains { $0.contains(coordinate) }
    }

    static func contains(_ coordinate: CLLocationCoordinate2D) -> Bool {
        guard CLLocationCoordinate2DIsValid(coordinate),
              coordinate.latitude.isFinite, coordinate.longitude.isFinite else { return false }
        return polygons.contains { $0.contains(coordinate) }
    }

    private static func contains(_ c: CLLocationCoordinate2D, ring: [[Double]]) -> Bool {
        guard ring.count >= 3 else { return false }
        var inside = false
        var previous = ring.count - 1
        for index in ring.indices {
            let a = ring[index], b = ring[previous]
            guard a.count >= 2, b.count >= 2 else { return false }
            if (a[1] > c.latitude) != (b[1] > c.latitude),
               c.longitude < (b[0] - a[0]) * (c.latitude - a[1]) / (b[1] - a[1]) + a[0] {
                inside.toggle()
            }
            previous = index
        }
        return inside
    }
}

import Foundation
import CoreLocation

/// Datum conversion at provider boundaries. Persisted coordinates, distances
/// and geofences use WGS84 [longitude, latitude]. Amap has a mainland routing
/// gate; MapKit uses explicit operations only after independent calibration.
/// Numerical round-trip residual is not evidence of geographical accuracy.
enum CoordinateConverter {
    // MARK: - Constants (state-bureau GCJ-02 algorithm)

    /// Semi-major axis of the Krasovsky 1940 ellipsoid (metres) — the datum the
    /// GCJ-02 offset algorithm is defined against.
    private static let a = 6_378_245.0
    /// Eccentricity squared of the Krasovsky 1940 ellipsoid.
    private static let ee = 0.006_693_421_622_965_943

    // MARK: - Public API

    /// Convert a WGS84 (GPS) coordinate to GCJ-02 for sending to Amap.
    /// This adapter only serves the mainland Amap route; other provider
    /// environments must establish their own datum independently.
    static func wgs84ToGcj02(_ wgs: CLLocationCoordinate2D, countryCode: String? = nil) -> CLLocationCoordinate2D {
        guard shouldConvert(wgs, countryCode: countryCode) else { return wgs }
        return applyingGCJ02Offset(wgs)
    }

    /// Explicit datum operation for a calibrated MapKit boundary, including
    /// service environments whose map coordinates cover Hong Kong or Macau.
    /// This does not decide which POI provider serves a geographical region.
    static func applyingGCJ02Offset(_ wgs: CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        guard CLLocationCoordinate2DIsValid(wgs), wgs.latitude.isFinite, wgs.longitude.isFinite else { return wgs }
        let (dLat, dLon) = offset(lat: wgs.latitude, lon: wgs.longitude)
        return CLLocationCoordinate2D(
            latitude: wgs.latitude + dLat,
            longitude: wgs.longitude + dLon
        )
    }

    /// Convert a GCJ-02 coordinate (as returned by Amap) back to WGS84 for
    /// storage / display in the app's native coordinate system.
    ///
    /// There is no closed-form inverse, so we treat `gcj` as a first guess for
    /// the unknown WGS84 point and refine it: re-encode the guess, measure how
    /// far the result drifts from `gcj`, subtract that drift, repeat. The small
    /// numerical residual does not establish the accuracy of the upstream POI.
    static func gcj02ToWgs84(_ gcj: CLLocationCoordinate2D, countryCode: String? = nil) -> CLLocationCoordinate2D {
        guard shouldConvert(gcj, countryCode: countryCode) else { return gcj }
        return removingGCJ02Offset(gcj)
    }

    /// Inverse of `applyingGCJ02Offset`; only a known datum authorizes its use.
    static func removingGCJ02Offset(_ gcj: CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        guard CLLocationCoordinate2DIsValid(gcj), gcj.latitude.isFinite, gcj.longitude.isFinite else { return gcj }
        var wgs = gcj
        // 5 iterations drives the residual below ~1e-7° (~1 cm) everywhere in
        // China; the loop is cheap and the extra rounds cost nothing.
        //
        // Apply `offset` directly rather than calling `wgs84ToGcj02`: the latter
        // re-runs the `isInsideChinaMainland` gate every iteration, so an
        // intermediate estimate that drifts a hair outside the bounding box near
        // a border would return the identity for that round and stall
        // convergence. We already gated `gcj` above, so the offset always applies.
        for _ in 0..<5 {
            let (dLat, dLon) = offset(lat: wgs.latitude, lon: wgs.longitude)
            // encoded = wgs + offset (what wgs84ToGcj02 would produce).
            wgs = CLLocationCoordinate2D(
                latitude: wgs.latitude + (gcj.latitude - (wgs.latitude + dLat)),
                longitude: wgs.longitude + (gcj.longitude - (wgs.longitude + dLon))
            )
        }
        return wgs
    }

    /// Offline mainland provider routing: country geometry with SAR exclusions.
    /// Coarse shoreline/border data is not suitable for navigation or surveying.
    static func isInsideChinaMainland(_ c: CLLocationCoordinate2D, countryCode: String? = nil) -> Bool {
        guard CLLocationCoordinate2DIsValid(c), c.latitude.isFinite, c.longitude.isFinite else { return false }
        // Country evidence handles reclaimed land, but cannot turn actual SAR
        // or Taiwan land into mainland. Rectangles also contain Fujian/Shenzhen.
        if isSpecialAdministrativeRegionOrTaiwan(c) { return false }
        if let code = countryCode?.uppercased(), !code.isEmpty { return code == "CN" }
        return MainlandChinaBoundary.contains(c)
    }

    private static func shouldConvert(_ coordinate: CLLocationCoordinate2D, countryCode: String?) -> Bool {
        guard CLLocationCoordinate2DIsValid(coordinate), coordinate.latitude.isFinite,
              coordinate.longitude.isFinite else { return false }
        return isInsideChinaMainland(coordinate, countryCode: countryCode)
    }

    static func isSpecialAdministrativeRegionOrTaiwan(_ c: CLLocationCoordinate2D) -> Bool {
        MainlandChinaBoundary.specialRegion(c) != nil
    }

    // MARK: - State-bureau offset

    /// The GCJ-02 offset (Δlat, Δlon in degrees) at a WGS84 point. This is the
    /// canonical published transform — magic polynomials and all.
    private static func offset(lat: Double, lon: Double) -> (dLat: Double, dLon: Double) {
        // Algorithm works in a coordinate frame shifted by (105°E, 35°N).
        let x = lon - 105.0
        let y = lat - 35.0

        var dLat = transformLat(x: x, y: y)
        var dLon = transformLon(x: x, y: y)

        let radLat = lat / 180.0 * .pi
        var magic = sin(radLat)
        magic = 1 - ee * magic * magic
        let sqrtMagic = magic.squareRoot()

        dLat = (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * .pi)
        dLon = (dLon * 180.0) / (a / sqrtMagic * cos(radLat) * .pi)
        return (dLat, dLon)
    }

    private static func transformLat(x: Double, y: Double) -> Double {
        var ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y
            + 0.1 * x * y + 0.2 * abs(x).squareRoot()
        ret += (20.0 * sin(6.0 * x * .pi) + 20.0 * sin(2.0 * x * .pi)) * 2.0 / 3.0
        ret += (20.0 * sin(y * .pi) + 40.0 * sin(y / 3.0 * .pi)) * 2.0 / 3.0
        ret += (160.0 * sin(y / 12.0 * .pi) + 320.0 * sin(y * .pi / 30.0)) * 2.0 / 3.0
        return ret
    }

    private static func transformLon(x: Double, y: Double) -> Double {
        var ret = 300.0 + x + 2.0 * y + 0.1 * x * x
            + 0.1 * x * y + 0.1 * abs(x).squareRoot()
        ret += (20.0 * sin(6.0 * x * .pi) + 20.0 * sin(2.0 * x * .pi)) * 2.0 / 3.0
        ret += (20.0 * sin(x * .pi) + 40.0 * sin(x / 3.0 * .pi)) * 2.0 / 3.0
        ret += (150.0 * sin(x / 12.0 * .pi) + 300.0 * sin(x / 30.0 * .pi)) * 2.0 / 3.0
        return ret
    }
}

import Foundation
import CoreLocation
import MapKit
import Observation

/// Session-scoped boundary between canonical WGS84 and the two MapKit APIs.
/// Country/geometry route verification; neither establishes a coordinate datum.
@MainActor @Observable
final class MapKitCoordinateSpace {
    enum Datum: String, Sendable { case wgs84, gcj02, unknown }
    enum Region: String, Sendable { case mainland, hongKong, macau }
    enum Style: String, CaseIterable, Sendable { case standard, imagery, hybrid }
    enum Area: Equatable { case calibrated(Region), wgs84, unresolved }

    struct Anchor: Sendable {
        let id: String
        let query: String
        let aliases: [String]
        let latitude: Double
        let longitude: Double
        let reference: String
        var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
    }
    struct Sample: Sendable {
        let anchorID: String
        let search: CLLocationCoordinate2D
        let nativeAnnotation: CLLocationCoordinate2D?
    }
    struct Profile: Sendable {
        let searchOutput: Datum
        let renderInput: Datum
        let verifiedAt: Date
    }
    enum CalibrationError: Error, LocalizedError {
        case unavailable, identityUnverified
        var errorDescription: String? {
            NSLocalizedString("map.coordinates.unavailable", comment: "Unverified map position")
        }
    }

    static let shared = MapKitCoordinateSpace()
    static let lifetime: TimeInterval = 300
    private(set) var profiles: [Region: Profile] = [:]
    private(set) var generation: UInt = 0
    private(set) var revision: UInt = 0
    /// The compatibility receipt is scoped to the runtime, public annotation
    /// API and flat map styles actually exercised in the native acceptance run.
    /// Other runtimes retain search/list/navigation and fail closed for pins.
    static var validatedStyles: Set<Style> {
        #if os(iOS)
        let os = ProcessInfo.processInfo.operatingSystemVersion
        return os.majorVersion == 26 && os.minorVersion == 5 ? [.standard] : []
        #else
        return []
        #endif
    }
    @ObservationIgnored private let renderStyles: Set<Style>
    @ObservationIgnored private var inFlight: [Region: Task<Profile, Error>] = [:]
    @ObservationIgnored private var retryAfter: [Region: Date] = [:]
    @ObservationIgnored private var routingHints: [String: Area] = [:]
    @ObservationIgnored private let fetchSample: @MainActor (Anchor) async throws -> Sample
    @ObservationIgnored private let resolveCountry: @MainActor (CLLocationCoordinate2D) async throws -> String?
    @ObservationIgnored private let now: () -> Date

    init(now: @escaping () -> Date = Date.init,
         renderStyles: Set<Style>? = nil,
         resolveCountry: (@MainActor (CLLocationCoordinate2D) async throws -> String?)? = nil,
         fetchSample: (@MainActor (Anchor) async throws -> Sample)? = nil) {
        self.now = now
        self.renderStyles = renderStyles ?? Self.validatedStyles
        self.fetchSample = fetchSample ?? Self.fetchNativeSample
        self.resolveCountry = resolveCountry ?? { c in
            let geocoder = CLGeocoder()
            let result = try await geocoder.reverseGeocodeLocation(.init(latitude: c.latitude, longitude: c.longitude))
            return result.first?.isoCountryCode
        }
    }

    static func area(for c: CLLocationCoordinate2D, countryCode: String? = nil) -> Area {
        guard valid(c) else { return .unresolved }
        switch MainlandChinaBoundary.specialRegion(c) {
        case "HKG": return .calibrated(.hongKong)
        case "MAC": return .calibrated(.macau)
        case "TWN": return .wgs84
        default: break
        }
        if let code = countryCode?.uppercased(), !code.isEmpty {
            switch code {
            case "CN": return .calibrated(.mainland)
            case "HK": return .calibrated(.hongKong)
            case "MO": return .calibrated(.macau)
            default: return .wgs84
            }
        }
        if MainlandChinaBoundary.contains(c) { return .calibrated(.mainland) }
        if MainlandChinaBoundary.isForeignLand(c) { return .wgs84 }
        // Generalized coastlines omit reclaimed land. Absence from the China
        // polygon is not positive evidence that a point uses WGS84.
        if (72...137).contains(c.longitude), (17...55).contains(c.latitude) { return .unresolved }
        return .wgs84
    }
    static func region(for c: CLLocationCoordinate2D) -> Region? {
        if case .calibrated(let region) = area(for: c) { return region }
        return nil
    }
    static func valid(_ c: CLLocationCoordinate2D) -> Bool {
        c.latitude.isFinite && c.longitude.isFinite && CLLocationCoordinate2DIsValid(c)
    }
    private func key(_ c: CLLocationCoordinate2D) -> String { "\(c.latitude),\(c.longitude)" }
    private func area(for c: CLLocationCoordinate2D, countryCode: String? = nil) -> Area {
        let geographical = Self.area(for: c, countryCode: countryCode)
        if geographical == .unresolved { return routingHints[key(c)] ?? .unresolved }
        return geographical
    }
    func profile(for c: CLLocationCoordinate2D, countryCode: String? = nil) -> Profile {
        let unknown = Profile(searchOutput: .unknown, renderInput: .unknown, verifiedAt: now())
        switch area(for: c, countryCode: countryCode) {
        case .wgs84: return .init(searchOutput: .wgs84, renderInput: .wgs84, verifiedAt: now())
        case .unresolved: return unknown
        case .calibrated(let region):
            guard let p = profiles[region], (0..<Self.lifetime).contains(now().timeIntervalSince(p.verifiedAt)) else { return unknown }
            return p
        }
    }

    /// Shared producer owns publication/backoff. Cancelling one caller cannot
    /// cancel another caller's calibration or erase a successfully loaded profile.
    func prepare(near c: CLLocationCoordinate2D, countryCode: String? = nil) async throws {
        guard Self.valid(c) else { throw CalibrationError.unavailable }
        var target = area(for: c, countryCode: countryCode)
        if target == .unresolved {
            let code = try await resolveCountry(c)
            try Task.checkCancellation()
            target = Self.area(for: c, countryCode: code)
            guard target != .unresolved else { throw CalibrationError.unavailable }
            if routingHints.count > 256 { routingHints.removeAll() }
            routingHints[key(c)] = target
            revision &+= 1
        } else if countryCode != nil {
            routingHints[key(c)] = target
        }
        guard case .calibrated(let region) = target else { return }
        if profile(for: c, countryCode: countryCode).searchOutput != .unknown { return }
        if let retry = retryAfter[region], now() < retry { throw CalibrationError.unavailable }
        let task: Task<Profile, Error>
        if let existing = inFlight[region] { task = existing }
        else {
            let epoch = generation
            task = Task { @MainActor [weak self, fetchSample, now] in
                guard let self else { throw CancellationError() }
                do {
                    let anchors = Self.anchors(for: region)
                    var samples: [Sample] = []
                    for anchor in anchors {
                        try Task.checkCancellation()
                        samples.append(try await fetchSample(anchor))
                    }
                    try Task.checkCancellation()
                    guard self.generation == epoch else { throw CancellationError() }
                    let result = Self.classify(anchors: anchors, samples: samples, at: now())
                    self.profiles[region] = result // Search may be known on iOS 17 without a render witness.
                    self.inFlight[region] = nil
                    self.retryAfter[region] = result.searchOutput == .unknown ? now().addingTimeInterval(30) : nil
                    self.revision &+= 1
                    return result
                } catch {
                    if self.generation == epoch {
                        self.inFlight[region] = nil
                        if !(error is CancellationError) { self.retryAfter[region] = now().addingTimeInterval(30) }
                    }
                    throw error
                }
            }
            inFlight[region] = task
        }
        let result = try await task.value
        try Task.checkCancellation()
        guard result.searchOutput != .unknown else { throw CalibrationError.unavailable }
    }

    func invalidate() {
        generation &+= 1
        for task in inFlight.values { task.cancel() }
        inFlight.removeAll(); profiles.removeAll(); retryAfter.removeAll(); routingHints.removeAll()
        revision &+= 1
    }
    /// Amap's adapter has already normalized these points to WGS84. Its
    /// mainland provenance can route reclaimed land missing from coarse coast
    /// geometry; it cannot establish a render datum or override foreign land.
    func registerMainlandProviderCoordinate(_ canonical: CLLocationCoordinate2D) {
        guard Self.area(for: canonical) == .unresolved else { return }
        let target = Area.calibrated(.mainland)
        if routingHints[key(canonical)] != target {
            routingHints[key(canonical)] = target
            revision &+= 1
        }
    }
    func supportsRenderStyle(_ style: Style, at coordinate: CLLocationCoordinate2D) -> Bool {
        if case .calibrated = area(for: coordinate) { return renderStyles.contains(style) }
        return true
    }
    func canonicalSearchCoordinate(_ raw: CLLocationCoordinate2D, countryCode: String? = nil) -> CLLocationCoordinate2D? {
        guard let c = convert(raw, datum: profile(for: raw, countryCode: countryCode).searchOutput, inverse: true) else { return nil }
        if let countryCode { routingHints[key(c)] = Self.area(for: c, countryCode: countryCode) }
        return c
    }
    func searchCoordinate(_ canonical: CLLocationCoordinate2D) -> CLLocationCoordinate2D? {
        convert(canonical, datum: profile(for: canonical).searchOutput, inverse: false)
    }
    func mapCoordinate(_ c: CLLocationCoordinate2D, style: Style = .standard) -> CLLocationCoordinate2D? {
        let datum = profile(for: c).renderInput
        if case .calibrated = area(for: c), !renderStyles.contains(style) { return nil }
        guard let raw = convert(c, datum: datum, inverse: false) else { return nil }
        // Exact paired coordinates only: a transformed coast point must remain
        // invertible, without applying a city-wide hint across a land border.
        routingHints[key(raw)] = area(for: c)
        return raw
    }
    func canonicalMapCoordinate(_ raw: CLLocationCoordinate2D, style: Style = .standard) -> CLLocationCoordinate2D? {
        if case .calibrated = area(for: raw), !renderStyles.contains(style) { return nil }
        guard let canonical = convert(raw, datum: profile(for: raw).renderInput, inverse: true) else { return nil }
        routingHints[key(canonical)] = area(for: raw)
        return canonical
    }
    private func convert(_ c: CLLocationCoordinate2D, datum: Datum, inverse: Bool) -> CLLocationCoordinate2D? {
        guard Self.valid(c) else { return nil }
        switch datum {
        case .wgs84: return c
        case .gcj02: return inverse ? CoordinateConverter.removingGCJ02Offset(c) : CoordinateConverter.applyingGCJ02Offset(c)
        case .unknown: return nil
        }
    }

    static func classify(_ observed: CLLocationCoordinate2D, against expected: CLLocationCoordinate2D) -> Datum {
        guard valid(observed), valid(expected) else { return .unknown }
        let origin = CLLocation(latitude: observed.latitude, longitude: observed.longitude)
        func distance(_ c: CLLocationCoordinate2D) -> Double { origin.distance(from: .init(latitude: c.latitude, longitude: c.longitude)) }
        let wgs = distance(expected), gcj = distance(CoordinateConverter.applyingGCJ02Offset(expected))
        // Accounts for building footprint/reference precision. This classifies
        // the datum; it does not establish a restaurant entrance to 120 m.
        guard min(wgs, gcj) <= 120, abs(wgs - gcj) > 250 else { return .unknown }
        return wgs < gcj ? .wgs84 : .gcj02
    }
    static func classify(anchors: [Anchor], samples: [Sample], at date: Date) -> Profile {
        func agreement(_ values: [Datum]) -> Datum {
            guard let first = values.first, first != .unknown, values.allSatisfy({ $0 == first }) else { return .unknown }
            return first
        }
        guard anchors.count >= 2, samples.count == anchors.count,
              Set(samples.map(\.anchorID)).count == anchors.count,
              Set(anchors.map(\.id)) == Set(samples.map(\.anchorID)) else {
            return .init(searchOutput: .unknown, renderInput: .unknown, verifiedAt: date)
        }
        let pairs = anchors.compactMap { anchor in samples.first(where: { $0.anchorID == anchor.id }).map { (anchor, $0) } }
        return .init(searchOutput: agreement(pairs.map { classify($0.1.search, against: $0.0.coordinate) }),
                     renderInput: agreement(pairs.map { pair in pair.1.nativeAnnotation.map { classify($0, against: pair.0.coordinate) } ?? .unknown }),
                     verifiedAt: date)
    }

    static func fetchNativeSample(_ anchor: Anchor) async throws -> Sample {
        let item = try await fetchNativeMapItem(anchor)
        let native: CLLocationCoordinate2D?
        if #available(iOS 18.0, macOS 15.0, *) { native = MKMapItemAnnotation(mapItem: item)?.coordinate } else { native = nil }
        return .init(anchorID: anchor.id, search: item.placemark.coordinate, nativeAnnotation: native)
    }

    /// Kept internal so the opt-in native acceptance run can compare the exact
    /// same result with a native annotation and a custom annotation on screen.
    static func fetchNativeMapItem(_ anchor: Anchor) async throws -> MKMapItem {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = anchor.query
        request.resultTypes = .pointOfInterest
        request.region = .init(center: anchor.coordinate, latitudinalMeters: 3_000, longitudinalMeters: 3_000)
        if #available(iOS 18.0, macOS 15.0, *) { request.regionPriority = .required }
        let search = MKLocalSearch(request: request)
        let deadline = Task { @MainActor in
            try await Task.sleep(for: .seconds(12)); search.cancel()
        }
        defer { deadline.cancel() }
        let response = try await withTaskCancellationHandler { try await search.start() }
            onCancel: { Task { @MainActor in search.cancel() } }
        func normalized(_ s: String) -> String {
            s.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .init(identifier: "en_US_POSIX"))
                .unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }.map(String.init).joined()
        }
        let aliases = Set(([anchor.query] + anchor.aliases).map(normalized))
        guard let item = response.mapItems.first(where: { aliases.contains(normalized($0.name ?? "")) }) else { throw CalibrationError.identityUnverified }
        return item
    }

    /// Versioned external references, never reverse-derived from MapKit or Amap.
    static func anchors(for region: Region) -> [Anchor] {
        switch region {
        case .mainland:
            return [
                .init(id: "Q223207", query: "东方明珠广播电视塔", aliases: ["Oriental Pearl Tower", "Oriental Pearl Radio & TV Tower", "The Oriental Pearl Radio & TV Tower", "东方明珠"],
                      latitude: 31 + 14.0/60 + 30.01/3600, longitude: 121 + 29.0/60 + 40.98/3600, reference: "https://www.wikidata.org/wiki/Q223207"),
                .init(id: "Q168400", query: "广州塔", aliases: ["Canton Tower", "Guangzhou Tower"],
                      latitude: 23 + 6.0/60 + 33.12/3600, longitude: 113 + 19.0/60 + 8.93/3600, reference: "https://www.wikidata.org/wiki/Q168400")
            ]
        case .hongKong:
            return [
                .init(id: "hko-trig-zero", query: "Hong Kong Observatory", aliases: ["香港天文台", "Hong Kong Observatory Headquarters"],
                      latitude: 22 + 18.0/60 + 7.3/3600, longitude: 114 + 10.0/60 + 27.6/3600, reference: "https://www.hko.gov.hk/en/gts/astron2024/files/HKO_almanac_2024.pdf"),
                .init(id: "Q837115", query: "Hong Kong City Hall", aliases: ["香港大会堂", "香港大會堂"],
                      latitude: 22.282, longitude: 114.16128, reference: "https://www.wikidata.org/wiki/Q837115")
            ]
        case .macau:
            return [
                .init(id: "Q4310094", query: "澳门仁慈堂", aliases: ["Holy House of Mercy", "Santa Casa da Misericórdia", "仁慈堂大楼", "仁慈堂大樓"],
                      latitude: 22 + 11.0/60 + 37.0/3600, longitude: 113 + 32.0/60 + 25.0/3600, reference: "https://www.wikidata.org/wiki/Q4310094"),
                .init(id: "Q909429", query: "澳门邮政总局", aliases: ["Macao Post and Telecommunications Bureau", "CTT Macau", "General Post Office", "邮政总局", "郵政總局", "邮政总局大楼", "郵政總局大樓", "澳门邮电局", "澳門郵政總局"],
                      latitude: 22 + 11.0/60 + 35.9/3600, longitude: 113 + 32.0/60 + 24.7/3600, reference: "https://www.wikidata.org/wiki/Q909429")
            ]
        }
    }
}

import Foundation
import CoreLocation
import MapKit
import Observation

/// Tertiary POI data source backed by Apple's `MKLocalSearch`. Free, native,
/// key-less — used by the deep-dive enrichment pipeline to thicken the signal
/// set for each place beyond what OSM/Overpass exposes.
///
/// Returns `OverpassService.POI` instances (the canonical POI shape across the
/// app) so results merge through the same dedupe path as Overpass + Foursquare.
/// Apple's `MKMapItem` exposes `pointOfInterestCategory`, `phoneNumber`, and
/// `url`; we map the category to an OSM-style `amenity`/`tourism`/`leisure`
/// tag so `OverpassService.category(for:)` keeps working unchanged. Hours and
/// rating are not part of the public MapItem surface, so those stay nil here
/// (Foursquare is the rating/hours source).
///
/// `@MainActor` because `MKLocalSearch` completion is dispatched on the main
/// queue and the rest of the explore pipeline is main-actor-bound.
@MainActor
@Observable
public final class MapKitPOIService {
    /// Failures that can occur while searching nearby places via MapKit.
    public enum MapKitPOIError: Error, LocalizedError {
        case searchFailed(String)

        public var errorDescription: String? {
            switch self {
            case .searchFailed(let msg):
                return msg
            }
        }
    }

    public private(set) var isFetching: Bool = false

    public init() {}

    /// Search Apple Maps POIs within `radiusMeters` of `coordinate`. `category`
    /// narrows the `MKPointOfInterestCategory` filter when provided; otherwise
    /// the search returns the full POI set in the region. Best-effort — returns
    /// an empty array rather than throwing on an empty result so callers can
    /// treat it as a soft enrichment source.
    public func fetchPOIs(
        near coordinate: CLLocationCoordinate2D,
        radiusMeters: Int = 1000,
        category: ExperienceCategory? = nil
    ) async throws -> [OverpassService.POI] {
        try Task.checkCancellation()
        isFetching = true
        defer { isFetching = false }

        let space = MapKitCoordinateSpace.shared
        try await space.prepare(near: coordinate)
        guard let searchCenter = space.searchCoordinate(coordinate) else { throw MapKitCoordinateSpace.CalibrationError.unavailable }
        let request = MKLocalPointsOfInterestRequest(
            center: searchCenter,
            radius: CLLocationDistance(radiusMeters)
        )
        if let category, let filter = Self.poiFilter(for: category) {
            request.pointOfInterestFilter = filter
        }

        let search = MKLocalSearch(request: request)
        let response: MKLocalSearch.Response
        do {
            response = try await Self.performSearch(search)
        } catch {
            try Task.checkCancellation()
            // An empty-result search surfaces as an error on some OS versions;
            // treat that as "no POIs" rather than a hard failure.
            let ns = error as NSError
            if ns.domain == MKError.errorDomain, ns.code == MKError.placemarkNotFound.rawValue {
                return []
            }
            throw MapKitPOIError.searchFailed(String(describing: error))
        }

        for item in response.mapItems {
            try Task.checkCancellation()
            try? await space.prepare(near: item.placemark.coordinate, countryCode: item.placemark.isoCountryCode)
        }
        try Task.checkCancellation()
        return Self.withinRadius(response.mapItems.compactMap { Self.poi(from: $0) }, center: coordinate, meters: radiusMeters)
    }

    /// Free-text POI search — the missing piece the local card filter can't do.
    ///
    /// `MKLocalPointsOfInterestRequest` (used by `fetchPOIs`) can only return
    /// "everything of category X near a point"; it takes no query string. To
    /// answer "find me izakayas" the user must be able to *type* — that's what
    /// `MKLocalSearch.Request.naturalLanguageQuery` is for. We bias the results
    /// toward the user's current map region so "coffee" surfaces nearby cafes
    /// rather than a city across the country.
    ///
    /// Best-effort: an empty MapKit result (which surfaces as an `MKError` on
    /// some OS versions) degrades to `[]` rather than throwing, so the caller
    /// can render an honest "no results" state instead of an error banner.
    ///
    /// - Parameters:
    ///   - query: The raw, user-typed search string. Whitespace-trimmed here;
    ///     an empty query short-circuits to `[]` (no wasted network call).
    ///   - coordinate: Center of the region to bias results toward.
    ///   - radiusMeters: Half-span of the search region (default 20 km — wide
    ///     enough to cover a city, tight enough to stay locally relevant).
    public func search(
        query: String,
        near coordinate: CLLocationCoordinate2D,
        radiusMeters: Int = 20_000
    ) async throws -> [OverpassService.POI] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        try Task.checkCancellation()

        isFetching = true
        defer { isFetching = false }

        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = trimmed
        let space = MapKitCoordinateSpace.shared
        try await space.prepare(near: coordinate)
        guard let searchCenter = space.searchCoordinate(coordinate) else { throw MapKitCoordinateSpace.CalibrationError.unavailable }
        request.region = MKCoordinateRegion(
            center: searchCenter,
            latitudinalMeters: CLLocationDistance(radiusMeters * 2),
            longitudinalMeters: CLLocationDistance(radiusMeters * 2)
        )
        request.resultTypes = .pointOfInterest
        if #available(iOS 18.0, macOS 15.0, *) { request.regionPriority = .required }

        let search = MKLocalSearch(request: request)
        let response: MKLocalSearch.Response
        do {
            response = try await Self.performSearch(search)
        } catch {
            try Task.checkCancellation()
            let ns = error as NSError
            if ns.domain == MKError.errorDomain, ns.code == MKError.placemarkNotFound.rawValue {
                return []
            }
            throw MapKitPOIError.searchFailed(String(describing: error))
        }

        for item in response.mapItems {
            try Task.checkCancellation()
            try? await space.prepare(near: item.placemark.coordinate, countryCode: item.placemark.isoCountryCode)
        }
        try Task.checkCancellation()
        return Self.withinRadius(response.mapItems.compactMap { Self.poi(from: $0) }, center: coordinate, meters: radiusMeters)
    }

    /// MKLocalSearch exposes explicit cancellation. Keep the non-Sendable SDK
    /// object behind a main-actor owner; cancellation can originate on any
    /// executor and is marshalled back to that actor without an unsafe capture.
    @MainActor
    private final class SearchOperation {
        let search: MKLocalSearch
        init(_ search: MKLocalSearch) { self.search = search }
        func cancel() { search.cancel() }
    }

    private static func performSearch(_ search: MKLocalSearch) async throws -> MKLocalSearch.Response {
        let operation = SearchOperation(search)
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            do {
                let response = try await operation.search.start()
                try Task.checkCancellation()
                return response
            } catch {
                try Task.checkCancellation()
                throw error
            }
        } onCancel: {
            Task { @MainActor in operation.cancel() }
        }
    }

    // MARK: - Mapping

    /// Convert an `MKMapItem` into an `OverpassService.POI`. Returns nil when
    /// the item has no name or usable coordinate.
    static func poi(from item: MKMapItem) -> OverpassService.POI? {
        let placemark = item.placemark
        let name = item.name ?? placemark.name
        guard let name, !name.isEmpty else { return nil }
        guard let coord = MapKitCoordinateSpace.shared.canonicalSearchCoordinate(placemark.coordinate, countryCode: placemark.isoCountryCode) else { return nil }
        guard CLLocationCoordinate2DIsValid(coord) else { return nil }

        var tags: [String: String] = ["name": name, "source": "mapkit"]
        if let osmTag = item.pointOfInterestCategory.flatMap(osmTag(for:)) {
            tags[osmTag.key] = osmTag.value
        }
        if let phone = item.phoneNumber, !phone.isEmpty {
            tags["phone"] = phone
        }
        if let url = item.url?.absoluteString, !url.isEmpty {
            tags["website"] = url
        }
        // A street-level address hint when the placemark carries one — helps
        // the AI write accurate howTo orientation steps.
        if let thoroughfare = placemark.thoroughfare {
            let withNumber = [placemark.subThoroughfare, thoroughfare]
                .compactMap { $0 }
                .joined(separator: " ")
            tags["addr"] = withNumber.isEmpty ? thoroughfare : withNumber
        }

        let stableId = stableInt64Id(forMapItem: item, name: name, coordinate: coord)
        return OverpassService.POI(
            osmId: stableId,
            name: name,
            nameEn: nil,
            lat: coord.latitude,
            lon: coord.longitude,
            tags: tags
        )
    }

    static func withinRadius(_ pois: [OverpassService.POI], center: CLLocationCoordinate2D, meters: Int) -> [OverpassService.POI] {
        let origin = CLLocation(latitude: center.latitude, longitude: center.longitude)
        return pois.filter { poi in
            let point = CLLocationCoordinate2D(latitude: poi.lat, longitude: poi.lon)
            return CLLocationCoordinate2DIsValid(point) && poi.lat.isFinite && poi.lon.isFinite
                && origin.distance(from: CLLocation(latitude: poi.lat, longitude: poi.lon)) <= Double(max(0, meters))
        }
    }

    /// Map an `MKPointOfInterestCategory` to an OSM-style tag (key, value) so
    /// `OverpassService.category(for:)` resolves it to the right bucket.
    static func osmTag(for category: MKPointOfInterestCategory) -> (key: String, value: String)? {
        switch category {
        case .cafe, .bakery:
            return ("amenity", "cafe")
        case .restaurant, .foodMarket:
            return ("amenity", "restaurant")
        case .nightlife, .brewery, .winery:
            return ("amenity", "bar")
        case .library:
            return ("amenity", "library")
        case .museum:
            return ("tourism", "museum")
        case .nationalPark, .park:
            return ("leisure", "park")
        case .beach:
            return ("natural", "beach")
        case .fitnessCenter:
            return ("leisure", "fitness_centre")
        case .aquarium, .zoo:
            return ("tourism", "zoo")
        default:
            return nil
        }
    }

    /// Build an `MKPointOfInterestFilter` that narrows the search to the
    /// categories matching one of our `ExperienceCategory` buckets. Returns nil
    /// for buckets with no clean MapKit equivalent (caller then searches all).
    static func poiFilter(for category: ExperienceCategory) -> MKPointOfInterestFilter? {
        let categories: [MKPointOfInterestCategory]
        switch category {
        case .coffee:    categories = [.cafe, .bakery]
        case .food:      categories = [.restaurant, .foodMarket]
        case .nightlife: categories = [.nightlife, .brewery, .winery]
        case .work:      categories = [.library]
        case .culture:   categories = [.museum]
        case .nature:    categories = [.nationalPark, .park, .beach, .aquarium, .zoo]
        case .wellness:  categories = [.fitnessCenter]
        case .hidden:    return nil
        }
        return MKPointOfInterestFilter(including: categories)
    }

    /// Hash an Apple Maps item into a stable `Int64`. Apple has no public stable
    /// identifier, so we hash name + rounded coordinate. The high marker bit
    /// (0x2000…) is distinct from the OSM range and Foursquare's 0x4000… bit,
    /// so MapKit ids never collide with the other two sources.
    static func stableInt64Id(
        forMapItem item: MKMapItem,
        name: String,
        coordinate: CLLocationCoordinate2D
    ) -> Int64 {
        // 4-decimal coordinate (~11 m) keeps the id stable across runs even if
        // Apple jitters the coordinate slightly.
        let rLat = (coordinate.latitude * 10_000).rounded() / 10_000
        let rLon = (coordinate.longitude * 10_000).rounded() / 10_000
        let seed = "\(name)|\(rLat)|\(rLon)"
        var hash: UInt64 = 1469598103934665603 // FNV offset basis
        for byte in seed.utf8 {
            hash ^= UInt64(byte)
            hash &*= 1099511628211 // FNV prime
        }
        let positive = hash & 0x7FFF_FFFF_FFFF_FFFF
        return Int64(bitPattern: positive | 0x2000_0000_0000_0000)
    }
}
